-- aspect_manager_sylvanas.lua — Dynamic Aspect switching for Hunters (TBC 2.5.5).
-- WHAT:  Auto-switch between Hawk (DPS), Viper (mana), Cheetah (OOC).
-- WHEN:  All Hunter specs (used by MM/Survival spec files; BM uses middleware).
-- WHY:   Never go OOM, never waste GCD on manual aspect.
-- SAFETY: nil-guarded; only suggests switches when not already in correct aspect.
-- DECISION: Hawk/Viper/Cheetah auto-switch; pure state machine driven by mana%.

local NS = _G.EaxRotations
if not NS then return {} end

local M = {}

--- Should we switch to Aspect of the Hawk?
-- In combat with mana above viper threshold.
--
-- @param state               table  Hunter state table
-- @param viper_threshold     number Mana % below which Viper is desired (default 20)
-- @return boolean
function M.should_hawk(state, viper_threshold)
    viper_threshold = viper_threshold or 20
    if not state then return false end
    if state.has_aspect_hawk then return false end
    -- Don't switch from Viper to Hawk until mana has recovered
    if state.has_aspect_viper then
        local recover_threshold = viper_threshold + 10
        if (state.mana_pct or 100) <= recover_threshold then return false end
    end
    return true
end

--- Should we switch to Aspect of the Viper?
-- In combat with mana below threshold.
--
-- @param state               table  Hunter state table
-- @param viper_threshold     number Mana % below which Viper is desired (default 20)
-- @return boolean
function M.should_viper(state, viper_threshold)
    viper_threshold = viper_threshold or 20
    if not state then return false end
    if state.has_aspect_viper then return false end
    if (state.mana_pct or 100) > viper_threshold then return false end
    return true
end

--- Should we switch to Aspect of the Cheetah?
-- Out of combat, no enemies nearby, not mounted.
--
-- @param state               table  Hunter state table
-- @param context             table  Rotation context
-- @return boolean
function M.should_cheetah(state, context)
    if not state then return false end
    if state.has_cheetah then return false end
    if state.in_combat then return false end
    if state.is_mounted then return false end
    -- Only if no valid enemy target nearby
    if context and context.has_valid_enemy_target then return false end
    -- Only if enemy count is low (no nearby threats)
    if (state.enemy_count or 0) > 0 then return false end
    return true
end

--- Determine the recommended aspect for current state.
-- Returns "hawk", "viper", "cheetah", or nil (no change needed).
--
-- @param state               table  Hunter state table
-- @param context             table  Rotation context
-- @param viper_threshold     number Mana % below which Viper is desired (default 20)
-- @return string|nil
function M.recommend_aspect(state, context, viper_threshold)
    viper_threshold = viper_threshold or 20
    if M.should_viper(state, viper_threshold) then return "viper" end
    if M.should_hawk(state, viper_threshold) then return "hawk" end
    if M.should_cheetah(state, context) then return "cheetah" end
    return nil
end

--- Legacy compatibility: try OOC aspect (Cheetah/Hawk swap).
-- Does nothing and returns false by default; reserved for middleware use.
-- @param context table
-- @return boolean
function M.try_ooc_aspect(context)
    return false
end

--- Legacy compatibility: try in-combat aspect swap (Hawk/Viper).
-- Does nothing and returns false by default; reserved for middleware use.
-- @param context table
-- @return boolean
function M.try_swap_aspect(context)
    return false
end

if NS then
    NS.AspectManager = M
end

return M
