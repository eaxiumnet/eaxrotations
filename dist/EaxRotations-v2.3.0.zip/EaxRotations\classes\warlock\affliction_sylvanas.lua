-- affliction_sylvanas -- warlock affliction_sylvanas rotation for TBC Anniversary (2.5.5).
-- WHAT:  priority-list strategies for affliction_sylvanas gameplay.
-- WHEN:  combat with valid enemy target.
-- WHY:   mirrors SimulationCraft / wowsims APL with TBC-era mechanics.
-- SAFETY: every state field read is nil-guarded via build_state() defaults; no on_update() allocs.

-- TBC Warlock Affliction priority list with multi-DoT cycling, Nightfall procs, and execute drain.

local NS = _G.EaxRotations
if not NS then return nil end
local pet_manager = require("shared/pet_manager_sylvanas")

local potion_helper = require("shared/potion_helper_sylvanas")
local DotTTD = require("shared/dot_ttd_gating_sylvanas")
local SPELLS = NS.WarlockSpells or {}
local _data_ok, TBC = pcall(require, "shared/tbc_data_sylvanas")
if not _data_ok or type(TBC) ~= "table" then TBC = { ITEMS = { potions = {} } } end
local TBC_POTIONS = (TBC.ITEMS and TBC.ITEMS.potions) or {}

-- IZI SDK for spread_dot multi-DoT support
local _izi = nil
do
    local ok, mod = pcall(require, "common/izi_sdk")
    if ok and type(mod) == "table" then _izi = mod end
end

--- Find a target missing the specified DoT using IZI spread_dot.
--- Returns nil if IZI is unavailable or no valid target found.
---@param spell_id number DoT spell ID to check
---@param radius number|nil Search radius (default 40)
---@return game_object|nil target Missing the DoT, or nil
local function find_dot_target(spell_id, radius)
    if not _izi then return nil end
    local ok, target = pcall(_izi.spread_dot, spell_id, radius or 40, 1, false)
    if ok and target then return target end
    return nil
end

-- ============================================================================
-- Debuff & Buff ID tables
-- ============================================================================
local CORRUPTION_DEBUFF      = { 27216, 25311, 11672, 11671, 7648, 6223, 6222, 172 }
local CURSE_OF_AGONY_DEBUFF  = { 27218, 11713, 11712, 11711, 6217, 1014, 980 }
local CURSE_OF_DOOM_DEBUFF   = { 30910, 603 }
local UNSTABLE_AFFL_DEBUFF   = { 30405, 30404, 30108 }
local SIPHON_LIFE_DEBUFF     = { 30911, 27264, 18881, 18880, 18879, 18265 }
local IMMOLATE_DEBUFF        = { 27215, 25309, 11668, 11667, 11665, 2941, 1094, 707, 348 }
local SHADOW_EMBRACE_DEBUFF  = { 32386, 32388, 32389, 32390, 32391 }
local ISB_DEBUFF = { 17800 } -- Shadow Vulnerability (ISB proc debuff)
local SEED_OF_CORRUPTION_DEBUFF = { 27285 }  -- the DoT that triggers the explosion
local CURSE_OF_ELEMENTS_DEBUFF = { 27228, 11722, 11721, 1490 }
local NIGHTFALL_BUFF         = { 17941 }  -- Shadow Trance
local SOULSHATTER_BUFF       = { 29858 }
local FEL_ARMOR_BUFF         = { 28189, 28176 }

local DOT_REFRESH_WINDOW = 1.5   -- refresh within last 1.5s per Research Angle 1 (clip <1.5s)
local SOUL_SHARD_CAPTURE_TTD = 5  -- TBC: Drain Soul is shard-capture only (mob about to die); sub-25% execute is Wrath, not TBC
local LIFE_TAP_SAFETY_HP = 35   -- don't Life Tap below this HP%

-- Snapshot-aware refresh constants
local SPELL_DMG_UPGRADE_RATIO = 1.08    -- Refresh only if 8%+ spell damage upgrade
local REFRESH_EXTRA_WINDOW = 1.5         -- Extra seconds past pandemic window for upgrade refresh    -- Local anti-spam: Soulshatter has 5min CD, use local timer as fallback for broken API
    local _last_soulshatter = 0

local LOCAL_SPELLS = {
    DrainLife       = NS.spell_action({ 27220, 27219, 11700, 11699, 7651, 709, 699, 689 }, "DrainLife"),
    DrainSoul       = NS.spell_action({ 27217, 11675, 8289, 8288, 1120 }, "DrainSoul"),
    DarkPact        = NS.spell_action({ 27265, 18938, 18937, 18220 }, "DarkPact"),
    Fear            = NS.spell_action({ 6215, 6213, 5782 }, "Fear"),
    HowlOfTerror    = NS.spell_action({ 17928, 5484 }, "HowlOfTerror"),
    CurseWeakness   = NS.spell_action({ 30909, 27224, 11708, 11707, 7646, 6205, 1108, 702 }, "CurseOfWeakness"),
    CurseTongues    = NS.spell_action({ 11719, 1714 }, "CurseOfTongues"),
    CurseExhaustion = NS.spell_action({ 18223 }, "CurseOfExhaustion"),
    CurseElements   = NS.spell_action({ 27228, 11722, 11721, 1490 }, "CurseOfElements"),
    DrainMana       = NS.spell_action({ 30908, 27221, 11704, 11703, 6226, 5138 }, "DrainMana"),
    HealthFunnel    = NS.spell_action({ 27259, 11695, 11694, 11693, 3700, 3699, 3698, 755 }, "HealthFunnel"),
    CreateHealthstone = NS.spell_action({ 27230, 11730, 11729, 6202, 6201, 5699 }, "CreateHealthstone"),
    FelDomination   = NS.spell_action({ 18708 }, "FelDomination"),
    DeathCoil       = NS.spell_action({ 27223, 17926, 17925, 6789 }, "DeathCoil"),
    ShadowWard      = NS.spell_action({ 28610, 11740, 11739, 6229 }, "ShadowWard"),
    DemonArmor      = NS.spell_action({ 27260, 11735, 11734, 11733, 1086, 706 }, "DemonArmor"),
    FelArmor        = NS.spell_action({ 28189, 28176 }, "FelArmor"),
    AmplifyCurse    = NS.spell_action({ 18288 }, "AmplifyCurse"),
    BloodFury       = NS.spell_action({ 33697, 20572 }, "BloodFury"),
    Berserking      = NS.spell_action({ 20554, 26297 }, "Berserking"),
    ArcaneTorrent   = NS.spell_action({ 25046 }, "ArcaneTorrent"),
    CreateSoulstone = NS.spell_action({ 27238, 20756, 20755, 20752, 693 }, "CreateSoulstone"),
    Shoot           = NS.spell_action({ 5019 }, "Shoot"),
}

local BLOODLUST_LOWER_RATIO = 1.04      -- More aggressive upgrade threshold during Bloodlust/Heroism
local BLOODLUST_BUFFS = { 2825, 32182 }  -- Bloodlust (Horde) / Heroism (Alliance)
local HEALTHSTONE_IDS = (TBC.ITEMS and TBC.ITEMS.healthstones) or { 22105, 22104, 22103, 19013, 19012, 19011, 5512 }
local SOULSTONE_BUFF_IDS = { 27239, 20765, 20764, 20763, 20762, 20707 }
local SOULSTONE_ITEMS = { 22116, 16896, 16895, 16893, 16892, 5232 }
local MANA_POTION_IDS = {
    TBC_POTIONS.crystal_mana or 33935,
    TBC_POTIONS.auchenai_mana or 32948,
    TBC_POTIONS.super_mana or 22832,
    TBC_POTIONS.super_rejuvenation or 22850,
    TBC_POTIONS.major_mana or 13444,
    TBC_POTIONS.superior_mana or 13443,
}

-- ============================================================================
-- State builder (pre-allocated)
-- ============================================================================
local aff_state = {
    -- DoT remains on target
    ua_remains = 0,
    corruption_remains = 0,
    agony_remains = 0,
    doom_remains = 0,
    siphon_remains = 0,
    immolate_remains = 0,	    -- Shadow Embrace stacks
	    se_stacks = 0,
	    -- Improved Shadow Bolt (Shadow Vulnerability) stacks
	    isb_stacks = 0,
    -- Proc
    nightfall_active = false,
    -- Resources
    mana_pct = 100,
    hp_pct = 100,
    target_hp = 100,
    -- Pet
    pet_alive = false,
    pet_health = 100,
    pet_mana = 100,
    -- Items
    mana_potion_id = nil,
    healthstone_id = nil,
    healthstone_ready = false,
    amplify_curse_ready = false,
    -- Soulstone / Wand
    has_soulstone = false,
    wand_learned = false,    -- Snapshot state (spell damage when DoT was applied — persisted across build_state calls)
    spell_damage = 0,
    snapshot_ua_dmg = 0,
    snapshot_corruption_dmg = 0,
    snapshot_siphon_dmg = 0,
    snapshot_immolate_dmg = 0,
    snapshot_target = nil,
    -- AoE
    enemy_count = 1,
}

local function build_state(context)
    local target = context.target
    if target then
        aff_state.ua_remains = NS.debuff_remains and NS.debuff_remains(target, UNSTABLE_AFFL_DEBUFF) or 0
        aff_state.corruption_remains = NS.debuff_remains and NS.debuff_remains(target, CORRUPTION_DEBUFF) or 0
        aff_state.agony_remains = NS.debuff_remains and NS.debuff_remains(target, CURSE_OF_AGONY_DEBUFF) or 0
        aff_state.doom_remains = NS.debuff_remains and NS.debuff_remains(target, CURSE_OF_DOOM_DEBUFF) or 0
        aff_state.siphon_remains = NS.debuff_remains and NS.debuff_remains(target, SIPHON_LIFE_DEBUFF) or 0
        aff_state.immolate_remains = NS.debuff_remains and NS.debuff_remains(target, IMMOLATE_DEBUFF) or 0
        aff_state.coe_remains = NS.debuff_remains and NS.debuff_remains(target, CURSE_OF_ELEMENTS_DEBUFF) or 0
        aff_state.se_stacks = NS.get_debuff_stacks and NS.get_debuff_stacks(target, SHADOW_EMBRACE_DEBUFF) or 0
        aff_state.isb_stacks = NS.get_debuff_stacks and NS.get_debuff_stacks(target, ISB_DEBUFF) or 0
        aff_state.target_hp = (target.get_health_percentage and target:get_health_percentage()) or 100
    else
        aff_state.ua_remains = 0
        aff_state.corruption_remains = 0
        aff_state.agony_remains = 0
        aff_state.siphon_remains = 0
        aff_state.immolate_remains = 0
        aff_state.coe_remains = 0
        aff_state.se_stacks = 0
        aff_state.isb_stacks = 0
	        aff_state.target_hp = 100
	    end
	    -- Nightfall proc
	    aff_state.nightfall_active = NS.has_player_buff(NIGHTFALL_BUFF)
	    -- Resources
	    aff_state.mana_pct = context.mana_pct or 100
	    aff_state.hp_pct = context.hp or 100
	    aff_state.enemy_count = context.enemy_count or 1            -- Pet status (via pet object if available)
            local pet = context.pet
            if pet then
                aff_state.pet_alive = (pet.is_alive and pet:is_alive())
                aff_state.pet_health = (pet.get_health_percentage and pet:get_health_percentage()) or 100
                aff_state.pet_mana = (pet.get_mana_percentage and pet:get_mana_percentage()) or 100
            else
                aff_state.pet_alive = false
                aff_state.pet_health = 100
                aff_state.pet_mana = 100
            end
            aff_state.has_pet = aff_state.pet_alive
            aff_state.has_demonic_sacrifice = context.me and NS.buff_up and NS.buff_up(context.me, {18789, 18790, 18791, 18792, 35701}) or false
            -- Amplify Curse readiness
            aff_state.amplify_curse_ready = NS.spell_ready(LOCAL_SPELLS.AmplifyCurse, NS.PLAYER_UNIT, { skip_range = true })
	    aff_state.spell_damage = context.spell_damage or 0  -- Current spell damage from NS (provided by middleware or character API)
	    -- Bloodlust/Heroism buff — enables more aggressive snapshot upgrade threshold
	    aff_state.has_bloodlust = context.me and NS.buff_up and NS.buff_up(context.me, BLOODLUST_BUFFS) or false
	    -- Maintain snapshot state: reset snapshots if DoT expired (stale)
	    local target_key = target and (target.get_guid and target:get_guid()) or nil
	    if target_key ~= aff_state.snapshot_target then
	        -- Target changed: reset all snapshots for fresh tracking
	        aff_state.snapshot_ua_dmg = 0
	        aff_state.snapshot_corruption_dmg = 0
	        aff_state.snapshot_siphon_dmg = 0
	        aff_state.snapshot_immolate_dmg = 0
	        aff_state.snapshot_target = target_key
	    else
	        -- Reset per-DoT snapshot if DoT completely fell off
	        if aff_state.ua_remains <= 0 then aff_state.snapshot_ua_dmg = 0 end
	        if aff_state.corruption_remains <= 0 then aff_state.snapshot_corruption_dmg = 0 end
	        if aff_state.siphon_remains <= 0 then aff_state.snapshot_siphon_dmg = 0 end
	        if aff_state.immolate_remains <= 0 then aff_state.snapshot_immolate_dmg = 0 end
	    end
    -- Items
    aff_state.mana_potion_id = nil
    for _, id in ipairs(MANA_POTION_IDS) do
        if NS.is_item_ready and NS.is_item_ready(id) then aff_state.mana_potion_id = id; break end
    end
    aff_state.healthstone_id = nil
    aff_state.healthstone_ready = false
    if NS.is_item_ready then
        for _, id in ipairs(HEALTHSTONE_IDS) do
            local ok, ready = pcall(NS.is_item_ready, id)
            if ok and ready then
                aff_state.healthstone_id = id
                aff_state.healthstone_ready = true
                break
            end
        end
    end
    -- Soulstone buff check (pre-combat self-buff)
    local me = context.me
    aff_state.has_soulstone = me and NS.has_player_buff and NS.has_player_buff(SOULSTONE_BUFF_IDS) or false
    if not aff_state.has_soulstone and NS.has_item then
        for _, id in ipairs(SOULSTONE_ITEMS) do
            if NS.has_item(id) then aff_state.has_soulstone = true; break end
        end
    end
    -- Wand (Shoot) spell readiness
    aff_state.wand_learned = NS.spell_exists and NS.spell_exists(5019) or false
    return aff_state
	end

	-- ============================================================================
	-- Snapshot upgrade logic
	-- ============================================================================
	
	-- Determine if current spell damage justifies refreshing a DoT early
	-- Returns true if: DoT expired, in pandemic window with upgrade, or about to fall off
	local function should_snapshot_upgrade(current_dmg, snapshotted_dmg, remains, refresh_window, ratio)
	    -- Always refresh if DoT has expired
	    if remains <= 0 then return true end
	    -- Always refresh if in pandemic window (about to fall off anyway)
	    if remains <= refresh_window then return true end
	    -- No previous snapshot to compare — refresh normally
	    if snapshotted_dmg <= 0 then return true end
	    -- Upgrade refresh: only if current damage is significantly higher AND still within extended window
	    if current_dmg >= snapshotted_dmg * ratio and remains <= refresh_window + REFRESH_EXTRA_WINDOW then
	        return true
	    end
	    return false
	end

	-- ============================================================================
	-- Helper functions
	-- ============================================================================

-- Select which curse to use based on context
local function select_curse(context, state)
    if context.is_pvp then
        if (context.enemy_healer or false) then return "tongues" end
        if (context.melee_on_you or false) then return "exhaustion" end
    end
    if (state.enemy_count or 0) >= 3 then return "elements" end  -- AoE benefit
    return "agony"  -- default: damage
end

-- Racial ability match gate for all racial strategies
local function racial_matches(context, state)
    if not context.has_valid_enemy_target then return false end
    if not context.in_combat then return false end
    -- TTD gate: don't use racials if target is about to die
    if context.ttd_known and context.ttd > 0 and context.ttd < 8 then return false end
    return true
end

-- Throttle DoT re-matches when aura APIs are broken on private servers.
local function broken_api_dot_throttled(spell_id)
    return NS.is_api_health_broken and NS.is_api_health_broken() and NS.recent_spell_cast and NS.recent_spell_cast(spell_id, 2.0)
end
local strategies = {

    -- Auto Damage Potion — gate on context.has_damage_potion (inventory_helper)
    { name = "DamagePotion",
      matches = function(context)
          if not context.in_combat then return false end
          if context.settings and context.settings.use_auto_potions == false then return false end
          if not context.has_damage_potion then return false end
          if not context.should_burst then return false end
          return true
      end,
      execute = function(context) return potion_helper.try_use_potion(context, potion_helper.DAMAGE_POTION_IDS) end },

    -- Pet State: set defensive when pet HP is critically low
    { name = "PetDefensive",
      matches = function(context, state)
          if not state.pet_alive then return false end
          if not (context.in_combat or false) then return false end
          if (state.pet_health or 100) > 35 then return false end
          return true
      end,
      execute = function() return pet_manager.set_defensive() end },
    -- Pet State: set passive when player HP critically low
    { name = "PetPassive",
      matches = function(context, state)
          if not state.pet_alive then return false end
          if not (context.in_combat or false) then return false end
          if (context.hp or 100) > 25 then return false end
          return true
      end,
      execute = function() return pet_manager.set_passive() end },
    -- Pet State: set aggressive during combat when pet is healthy
    { name = "PetAggressive",
      matches = function(context, state)
          if not state.pet_alive then return false end
          if not (context.in_combat or false) then return false end
          if (state.pet_health or 100) < 50 then return false end
          return true
      end,
      execute = function() return pet_manager.set_aggressive() end },

    -- ------------------------------------------------------------------------
    -- 1. Death Coil (survival heal + CC)
    -- ------------------------------------------------------------------------
    {
        name = "DeathCoilSurvival",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if (state.hp_pct or 100) > 30 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.DeathCoil, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.DeathCoil, context.target, "[AFFL] Death Coil (survival + heal)")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 2. Healthstone
    -- ------------------------------------------------------------------------
    {
        name = "Healthstone",
        matches = function(context, state)
            local auto_hs = (context.settings and context.settings.auto_healthstone) ~= false
            if not auto_hs then return false end
            local threshold = (context.settings and context.settings.healthstone_hp_threshold) or 30
            if (context.hp or 100) > threshold then return false end
            if context.is_casting then return false end
            return state and state.healthstone_ready == true
        end,
        execute = function(_, state)
            return state and state.healthstone_id and NS.use_item_by_id and NS.use_item_by_id(state.healthstone_id) or false
        end,
    },

    -- ------------------------------------------------------------------------
    -- 3. Soulshatter (threat reduction)
    -- ------------------------------------------------------------------------
    {
        name = "Soulshatter",
        matches = function(context, state)
            if not context.in_combat then return false end
            if context.threat_pct and context.threat_pct < 90 then return false end
            local me = context.me or (NS.GetPlayer and NS.GetPlayer())
            if not me then return false end
            -- Local timer: Soul shatter has 5min CD
            if (NS.time_now() - _last_soulshatter) < 290 then return false end
            if NS.cooldown_remains(SPELLS.Soulshatter, 300) > 0 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.Soulshatter, me, { skip_range = true }) or false
        end,
        execute = function(context)
            local me = context.me or (NS.GetPlayer and NS.GetPlayer()) or NS.PLAYER_UNIT
            local ok = NS.try_cast(SPELLS.Soulshatter, me, "[AFFL] Soulshatter", { skip_range = true })
            if ok then _last_soulshatter = NS.time_now() end
            return ok
        end,
    },

    -- ------------------------------------------------------------------------
    -- 4. Nightfall proc — instant Shadow Bolt
    -- ------------------------------------------------------------------------
    {
        name = "NightfallProc",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if not state.nightfall_active then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.ShadowBolt, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.ShadowBolt, context.target, "[AFFL] Nightfall instant Shadow Bolt")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 5. Corruption (instant DoT — apply before UA for efficiency)
    -- ------------------------------------------------------------------------
    {
        name = "CorruptionDoT",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if broken_api_dot_throttled(27216) then return false end
            if (state.corruption_remains or 0) > DOT_REFRESH_WINDOW then return false end
            -- Snapshot-aware: hold refresh if current spell damage is not an upgrade over snapshotted
            local ratio = state.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
            if (state.corruption_remains or 0) > 0 and not should_snapshot_upgrade(state.spell_damage or 0, state.snapshot_corruption_dmg or 0, state.corruption_remains or 0, DOT_REFRESH_WINDOW, ratio) then return false end
            -- DoT TTD gating
            local ttd_threshold = (context.settings and context.settings.dot_ttd_threshold or 50) / 100
            if DotTTD.should_skip_dot(context.ttd, DotTTD.DOT_DURATIONS.corruption, ttd_threshold) then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.Corruption, context.target) or false
        end,
        execute = function(context)
            local ok = NS.try_cast(SPELLS.Corruption, context.target, "[AFFL] Corruption")
            if ok and aff_state.spell_damage then aff_state.snapshot_corruption_dmg = aff_state.spell_damage end
            return ok
        end,
    },
    -- Corruption Spread — multi-DoT via IZI spread_dot
    {
        name = "CorruptionSpread",
        matches = function(context, state)
            if not _izi then return false end
            if (state.corruption_remains or 0) > DOT_REFRESH_WINDOW then return false end
            local target = find_dot_target(CORRUPTION_DEBUFF[1])
            if not target then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.Corruption, target) or false
        end,
        execute = function(context)
            local target = find_dot_target(CORRUPTION_DEBUFF[1])
            if not target then return false end
            return NS.try_cast(SPELLS.Corruption, target, "[AFFL] Corruption Spread")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 5a. MovingCorruption (instant DoT while moving)
    -- ------------------------------------------------------------------------
    {
        name = "MovingCorruption",
        matches = function(context, state)
            if not context.is_moving then return false end
            if not context.has_valid_enemy_target then return false end
            if broken_api_dot_throttled(27216) then return false end
            if (state.corruption_remains or 0) > DOT_REFRESH_WINDOW then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.Corruption, context.target) or false
        end,
        execute = function(context)
            local ok = NS.try_cast(SPELLS.Corruption, context.target, "[AFFL] Corruption (moving)")
            if ok and aff_state.spell_damage then aff_state.snapshot_corruption_dmg = aff_state.spell_damage end
            return ok
        end,
    },

    -- ------------------------------------------------------------------------
    -- 6. Unstable Affliction (primary DoT — dispel protection, 1.5s cast)
    -- ------------------------------------------------------------------------
    {
        name = "UnstableAffliction",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if broken_api_dot_throttled(30405) then return false end
            if (state.ua_remains or 0) > DOT_REFRESH_WINDOW then return false end
            -- Snapshot-aware: hold refresh if current spell damage is not an upgrade over snapshotted
            local ratio = state.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
            if (state.ua_remains or 0) > 0 and not should_snapshot_upgrade(state.spell_damage or 0, state.snapshot_ua_dmg or 0, state.ua_remains or 0, DOT_REFRESH_WINDOW, ratio) then return false end
            -- DoT TTD gating
            local ttd_threshold = (context.settings and context.settings.dot_ttd_threshold or 50) / 100
            if DotTTD.should_skip_dot(context.ttd, DotTTD.DOT_DURATIONS.unstable_affliction, ttd_threshold) then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.UnstableAffliction, context.target) or false
        end,
        execute = function(context)
            local ok = NS.try_cast(SPELLS.UnstableAffliction, context.target, "[AFFL] Unstable Affliction")
            if ok and aff_state.spell_damage then aff_state.snapshot_ua_dmg = aff_state.spell_damage end
            return ok
        end,
    },

    -- ------------------------------------------------------------------------
    -- 7. Siphon Life (DoT + self-heal, if talented)
    -- Requires ISB debuff on target to maximize Shadow damage benefit
    -- ------------------------------------------------------------------------
    {
        name = "SiphonLife",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if (state.siphon_remains or 0) > DOT_REFRESH_WINDOW then return false end
            -- Snapshot-aware: hold refresh if current spell damage is not an upgrade over snapshotted
            local ratio = state.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
            if (state.siphon_remains or 0) > 0 and not should_snapshot_upgrade(state.spell_damage or 0, state.snapshot_siphon_dmg or 0, state.siphon_remains or 0, DOT_REFRESH_WINDOW, ratio) then return false end
            -- DoT TTD gating
            local ttd_threshold = (context.settings and context.settings.dot_ttd_threshold or 50) / 100
            if DotTTD.should_skip_dot(context.ttd, DotTTD.DOT_DURATIONS.siphon_life, ttd_threshold) then return false end
            -- Siphon Life is talent-gated; spell won't be ready if not learned
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.SiphonLife, context.target) or false
        end,
        execute = function(context)
            local ok = NS.try_cast(SPELLS.SiphonLife, context.target, "[AFFL] Siphon Life")
            if ok and aff_state.spell_damage then aff_state.snapshot_siphon_dmg = aff_state.spell_damage end
            return ok
        end,
    },
    -- Siphon Life Spread — multi-DoT via IZI spread_dot
    {
        name = "SiphonLifeSpread",
        matches = function(context, state)
            if not _izi then return false end
            if (state.siphon_remains or 0) > DOT_REFRESH_WINDOW then return false end
            local target = find_dot_target(SIPHON_LIFE_DEBUFF[1])
            if not target then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.SiphonLife, target) or false
        end,
        execute = function(context)
            local target = find_dot_target(SIPHON_LIFE_DEBUFF[1])
            if not target then return false end
            return NS.try_cast(SPELLS.SiphonLife, target, "[AFFL] Siphon Life Spread")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 8. Curse of Doom (long-lived PvE targets)
    -- ------------------------------------------------------------------------
    {
        name = "CurseOfDoom",
        matches = function(context, state)
            if not context.target then return false end
            if not context.has_valid_enemy_target then return false end
            -- Don't refresh if already applied and still ticking
            if (state.doom_remains or 0) > DOT_REFRESH_WINDOW then return false end
            -- Only on long-lived targets (Doom takes 60s to tick)
            if context.ttd_known and context.ttd < 62 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.CurseOfDoom, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.CurseOfDoom, context.target, "[AFFL] Curse of Doom")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 8a. Curse of Elements (raid debuff — higher priority than CoA in groups)
    -- ------------------------------------------------------------------------
    {
        name = "CurseOfElements",
        matches = function(context, state)
            if not context.target then return false end
            -- Only in group content when no other warlock has it
            if not context.is_group then return false end
            if (state and state.coe_remains or 0) > DOT_REFRESH_WINDOW then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.CurseElements, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.CurseElements, context.target, "[AFFL] Curse of Elements")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 9. Curse of Agony (long DoT curse)
    -- ------------------------------------------------------------------------
    {
        name = "CurseOfAgony",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            -- Skip in groups when Curse of Elements is active (TBC: one curse per target)
            if context.is_group and (state and state.coe_remains or 0) > 0 then return false end
            local curse = select_curse(context, state)
            if curse ~= "agony" then return false end
            if (state.agony_remains or 0) > DOT_REFRESH_WINDOW then return false end
            -- On short-lived targets, CoA may not run full duration
            if context.ttd_known and context.ttd < 8 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.CurseOfAgony, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.CurseOfAgony, context.target, "[AFFL] Curse of Agony")
        end,
    },
    -- Curse of Agony Spread — multi-DoT via IZI spread_dot
    {
        name = "CurseOfAgonySpread",
        matches = function(context, state)
            if not _izi then return false end
            if (state.agony_remains or 0) > DOT_REFRESH_WINDOW then return false end
            if context.ttd_known and context.ttd < 8 then return false end
            local target = find_dot_target(CURSE_OF_AGONY_DEBUFF[1])
            if not target then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.CurseOfAgony, target) or false
        end,
        execute = function(context)
            local target = find_dot_target(CURSE_OF_AGONY_DEBUFF[1])
            if not target then return false end
            return NS.try_cast(SPELLS.CurseOfAgony, target, "[AFFL] Curse of Agony Spread")
        end,
    },

    -- ------------------------------------------------------------------------
    -- Drain Life (sustain — fires after all DoTs are applied)
    -- ------------------------------------------------------------------------
    {
        name = "DrainLife",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if (state.hp_pct or 100) > 55 then return false end
            if context.is_channeling then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.DrainLife, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.DrainLife, context.target, "[AFFL] Drain Life sustain")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 9. Immolate (optional DoT, lower prio for Affliction)
    -- ------------------------------------------------------------------------
    {
        name = "ImmolateDoT",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if (state.immolate_remains or 0) > DOT_REFRESH_WINDOW then return false end
            -- Skip if target TTD is very short
            if context.ttd_known and context.ttd < 5 then return false end
            -- Snapshot-aware: hold refresh if current spell damage is not an upgrade over snapshotted
            local ratio = state.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
            if (state.immolate_remains or 0) > 0 and not should_snapshot_upgrade(state.spell_damage or 0, state.snapshot_immolate_dmg or 0, state.immolate_remains or 0, DOT_REFRESH_WINDOW, ratio) then return false end
            -- DoT TTD gating
            local ttd_threshold = (context.settings and context.settings.dot_ttd_threshold or 50) / 100
            if DotTTD.should_skip_dot(context.ttd, DotTTD.DOT_DURATIONS.immolate, ttd_threshold) then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.Immolate, context.target) or false
        end,
        execute = function(context)
            local ok = NS.try_cast(SPELLS.Immolate, context.target, "[AFFL] Immolate")
            if ok and aff_state.spell_damage then aff_state.snapshot_immolate_dmg = aff_state.spell_damage end
            return ok
        end,
    },

    -- ------------------------------------------------------------------------
    -- 9a. Amplify Curse (before CoD/CoA/CoE — 3 min cooldown)
    -- ------------------------------------------------------------------------
    -- Fires when a curse is about to be applied and Amplify Curse is off cooldown
    {
        name = "AmplifyCurse",
        matches = function(context, state)
            if not context.target then return false end
            if not state.amplify_curse_ready then return false end
            -- Gate: setting check
            if context.settings and context.settings.aff_use_amplify_curse == false then return false end
            -- Only use on targets that live long enough (60s+ to warrant 3min CD)
            if context.ttd_known and context.ttd < 60 then return false end
            -- Check if a curse is about to be applied (CoD, CoA, or Curse of Elements)
            local about_to_curse = false
            if (state.agony_remains or 0) <= DOT_REFRESH_WINDOW and context.ttd_known and context.ttd >= 8 then about_to_curse = true end
            if (state.doom_remains or 0) <= DOT_REFRESH_WINDOW and context.ttd_known and context.ttd >= 62 then about_to_curse = true end
            -- Also check CoD cooldown via spell_ready (60s CD, if ready with no debuff it's about to be cast)
            if context.target and (state.doom_remains or 0) <= 0 and NS.spell_ready(SPELLS.CurseOfDoom, context.target) then about_to_curse = true end
            return about_to_curse
        end,
        execute = function()
            return NS.try_cast(LOCAL_SPELLS.AmplifyCurse, NS.PLAYER_UNIT, "[AFFL] Amplify Curse", { skip_range = true })
        end,
    },

    -- ------------------------------------------------------------------------
    -- 10. Seed of Corruption (AoE 3+ targets)
    -- ------------------------------------------------------------------------
    {
        name = "SeedOfCorruption",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            local min_targets = context.settings and context.settings.aff_seed_targets or 3
            if (state.enemy_count or 0) < min_targets then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.SeedOfCorruption, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.SeedOfCorruption, context.target, "[AFFL] Seed of Corruption")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 11. Drain Soul (TBC shard capture: channel as the mob dies to gain a shard)
    -- ------------------------------------------------------------------------
    {
        name = "DrainSoulExecute",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            -- TBC: Drain Soul is NOT a DPS execute (that is a Wrath mechanic).
            -- Channel it only when the mob is about to die so it dies during the
            -- channel and yields a Soul Shard. Drain Soul ~62 dps vs Shadow Bolt
            -- ~250 dps, so channeling it for DPS is a large loss.
            if not (context.ttd_known and context.ttd and context.ttd > 0 and context.ttd <= SOUL_SHARD_CAPTURE_TTD) then return false end
            if context.is_channeling then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.DrainSoul, context.target) or false
        end,
        execute = function(context, state)
            return NS.try_cast(LOCAL_SPELLS.DrainSoul, context.target,
                string.format("[AFFL] Drain Soul shard capture (ttd %.0fs)", (context and context.ttd) or 0))
        end,
    },

    -- ------------------------------------------------------------------------
    -- 12. Shadow Bolt (filler)
    -- ------------------------------------------------------------------------
    {
        name = "PreCombatPull",
        matches = function(context)
            if context.in_combat then return false end
            if not context.has_valid_enemy_target then return false end
            -- Range check: Shadow Bolt has 30yd range
            if context.target_range and context.target_range > 28 then return false end
            -- Pre-cast Shadow Bolt on pull timer targets
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.ShadowBolt, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.ShadowBolt, context.target, "[AFFL] Pre-combat Shadow Bolt")
        end,
    },

    {
        name = "ShadowEmbraceMaintenance",
        matches = function(context, state)
            if not context.has_valid_enemy_target then return false end
            if (state.se_stacks or 0) >= 5 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.ShadowBolt, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.ShadowBolt, context.target, "[AFFL] Shadow Embrace maintenance")
        end,
    },

    {
        name = "ShadowBoltFiller",
        matches = function(context)
            if not context.has_valid_enemy_target then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.ShadowBolt, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.ShadowBolt, context.target, "[AFFL] Shadow Bolt filler")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 13. Life Tap (HP → Mana)
    -- ------------------------------------------------------------------------
    {
        name = "LifeTap",
        max_mana = 65,
        matches = function(context, state)
            local threshold = math.min(context.settings and context.settings.aff_life_tap_mana or 30, 65)
            if (state.mana_pct or 100) > threshold then return false end
            if (state.hp_pct or 100) < LIFE_TAP_SAFETY_HP then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(SPELLS.LifeTap, NS.PLAYER_UNIT, { skip_range = true }) or false
        end,
        execute = function()
            return NS.try_cast(SPELLS.LifeTap, NS.PLAYER_UNIT, "[AFFL] Life Tap")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 14. Dark Pact (pet mana drain)
    -- ------------------------------------------------------------------------
    {
        name = "DarkPact",
        matches = function(context, state)
            local threshold = context.settings and context.settings.aff_dark_pact_mana or 20
            if (state.mana_pct or 100) > threshold then return false end
            if not state.pet_alive then return false end
            if (state.pet_mana or 0) < 20 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.DarkPact, NS.PLAYER_UNIT, { skip_range = true }) or false
        end,
        execute = function()
            return NS.try_cast(LOCAL_SPELLS.DarkPact, NS.PLAYER_UNIT, "[AFFL] Dark Pact")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 16. Mana potion
    -- ------------------------------------------------------------------------
    {
        name = "ManaPotion",
        matches = function(context, state)
            local threshold = context.settings and context.settings.aff_mana_potion or 15
            if (state.mana_pct or 100) > threshold then return false end
            return state.mana_potion_id ~= nil
        end,
        execute = function(_, state)
            if NS.use_item_by_id then NS.use_item_by_id(state.mana_potion_id) end
            return true
        end,
    },

    -- ------------------------------------------------------------------------
    -- Racial abilities (off-GCD, usable in combat)
    -- ------------------------------------------------------------------------
    {
        name = "RacialBerserking",
        matches = function(context, state) return racial_matches(context, state) and NS.spell_ready(LOCAL_SPELLS.Berserking, NS.PLAYER_UNIT, { skip_range = true }) end,
        execute = function() return NS.try_cast(LOCAL_SPELLS.Berserking, NS.PLAYER_UNIT, "[AFFL] Berserking", { skip_range = true }) end,
    },
    {
        name = "RacialBloodFury",
        matches = function(context, state) return racial_matches(context, state) and NS.spell_ready(LOCAL_SPELLS.BloodFury, NS.PLAYER_UNIT, { skip_range = true }) end,
        execute = function() return NS.try_cast(LOCAL_SPELLS.BloodFury, NS.PLAYER_UNIT, "[AFFL] Blood Fury", { skip_range = true }) end,
    },
    {
        name = "RacialArcaneTorrent",
        matches = function(context, state) return racial_matches(context, state) and NS.spell_ready(LOCAL_SPELLS.ArcaneTorrent, context.target) end,
        execute = function(context) return NS.try_cast(LOCAL_SPELLS.ArcaneTorrent, context.target, "[AFFL] Arcane Torrent") end,
    },

    -- ------------------------------------------------------------------------
    -- PvP Section
    -- ------------------------------------------------------------------------
    {
        name = "CC_Fear",
        matches = function(context)
            if not (context.is_pvp or context.is_group) then return false end
            if not context.target then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.Fear, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.Fear, context.target, "[AFFL] Fear")
        end,
    },
    {
        name = "CC_HowlOfTerror",
        matches = function(context)
            if not (context.is_pvp or context.is_group) then return false end
            if not context.melee_on_you then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.HowlOfTerror, NS.PLAYER_UNIT, { skip_range = true }) or false
        end,
        execute = function()
            return NS.try_cast(LOCAL_SPELLS.HowlOfTerror, NS.PLAYER_UNIT, "[AFFL] Howl of Terror")
        end,
    },
    {
        name = "PvP_CurseExhaustion",
        matches = function(context, state)
            if not context.is_pvp then return false end
            if not context.target then return false end
            if not context.melee_on_you then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.CurseExhaustion, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.CurseExhaustion, context.target, "[AFFL PvP] Curse of Exhaustion kite")
        end,
    },
    {
        name = "PvP_CurseTongues",
        matches = function(context)
            if not (context.is_pvp or context.is_group) then return false end
            if not context.target then return false end
            if not context.enemy_caster then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.CurseTongues, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.CurseTongues, context.target, "[AFFL PvP] Curse of Tongues")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 21. Fel Armor (out of combat + in-combat refresh if dropped)
    -- ------------------------------------------------------------------------
    {
        name = "FelArmorBuff",
        matches = function(context)
            local me = context.me or (NS.GetPlayer and NS.GetPlayer())
            if me and NS.buff_remains(me, FEL_ARMOR_BUFF) > 0 then return false end
            -- In combat: only refresh if not channeling (don't interrupt Drain Soul)
            if context.in_combat and context.is_channeling then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.FelArmor, me or NS.PLAYER_UNIT, { skip_range = true }) or false
        end,
        execute = function()
            return NS.try_cast(LOCAL_SPELLS.FelArmor, NS.PLAYER_UNIT, "[AFFL] Fel Armor")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 22. Health Funnel (heal pet)
    -- ------------------------------------------------------------------------
    {
        name = "HealthFunnelPet",
        matches = function(context, state)
            if not state.pet_alive then return false end
            if (state.pet_health or 100) > 40 then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.HealthFunnel, context.pet) or false
        end,
        execute = function(context)
            if context.pet then
                return NS.try_cast(LOCAL_SPELLS.HealthFunnel, context.pet, "[AFFL] Health Funnel pet")
            end
            return false
        end,
    },

    -- ------------------------------------------------------------------------
    -- 24. Shadow Ward (shadow absorb)
    -- ------------------------------------------------------------------------
    {
        name = "ShadowWard",
        matches = function(context)
            if not (context.is_pvp or context.is_group) then return false end
            if not context.enemy_shadow_caster then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.ShadowWard, NS.PLAYER_UNIT, { skip_range = true }) or false
        end,
        execute = function()
            return NS.try_cast(LOCAL_SPELLS.ShadowWard, NS.PLAYER_UNIT, "[AFFL PvP] Shadow Ward")
        end,
    },

    -- ------------------------------------------------------------------------
    -- 25. Soulstone (pre-combat self-buff)
    -- ------------------------------------------------------------------------
    {
        name = "SelfSoulstone",
        matches = function(context, state)
            if context.in_combat then return false end
            if state.has_soulstone then return false end
            -- Require at least one soul shard to create
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.CreateSoulstone, NS.PLAYER_UNIT, { skip_range = true }) or false
        end,
        execute = function()
            return NS.try_cast(LOCAL_SPELLS.CreateSoulstone, NS.PLAYER_UNIT, "[AFFL] Create Soulstone (self-buff)")
        end,
    },

    {
        name = "SummonFelhunter",
        matches = function(context, state)
            if context.in_combat then return false end
            if context.has_valid_enemy_target then return false end
            if state and state.has_pet then return false end
            -- Do NOT re-summon if Demonic Sacrifice aura is already active
            if state and state.has_demonic_sacrifice then return false end
            return NS.is_spell_learned and NS.is_spell_learned(691)
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.SummonFelhunter, NS.PLAYER_UNIT, "[AFFL] Summon Felhunter", { skip_range = true })
        end,
    },

    -- ------------------------------------------------------------------------
    -- 26. Wand (Shoot) — mana conservation fallback
    -- ------------------------------------------------------------------------
    {
        name = "Wand",
        matches = function(context, state)
            if not context.in_combat then return false end
            if not state.wand_learned then return false end
            local wand_threshold = context.settings and context.settings.aff_wand_mana or 15
            if (state.mana_pct or 100) >= wand_threshold then return false end
            if not context.has_valid_enemy_target then return false end
            return NS.spell_ready ~= nil and NS.spell_ready(LOCAL_SPELLS.Shoot, context.target) or false
        end,
        execute = function(context)
            return NS.try_cast(LOCAL_SPELLS.Shoot, context.target, "[AFFL] Wand (mana conservation)")
        end,
    },
}

NS.rotation_registry:register("affliction", strategies, { get_state = build_state })
return { strategies = strategies, build_state = build_state }


