-- potion_helper_sylvanas.lua -- expose known potion IDs (healing/mana/etc) + a try_use_potion helper.
-- WHAT:   expose known potion IDs (healing/mana/etc) + a try_use_potion helper
-- WHEN:   called per-frame under HP/mana thresholds by all specs
-- WHY:    removes per-spec hardcoded item IDs; keeps IDs in one file
-- SAFETY: is_spell_learned + in_bag check; combat-mode gating
-- DECISION: consumed by specs via require(); no on_update side-effects.

-- Centralises potion ID lists and the pcall-safe use_item loop so
-- class rotation files can share a single copy.

local M = {}
local NS = _G.EaxRotations

-- Health Potion IDs (TBC best-to-worst, with Classic fallbacks)
M.HEALTH_POTION_IDS = { 22829, 13446, 3928, 1710, 929, 858, 118 }

-- Mana Potion IDs (TBC best-to-worst, with Classic fallbacks)
M.MANA_POTION_IDS = { 33935, 32948, 22850, 22832, 13444, 13443, 6149, 3827, 3385, 2455 }

-- Damage/Combat Potion IDs (Destruction > Haste > Heroic > Insane Strength)
M.DAMAGE_POTION_IDS = { 22840, 22839, 22838, 22837, 13453, 13452, 13454 }

-- Healthstone IDs (TBC best-to-worst: 1.4 > 1.3 > 1.2 > 1.1 > Minor)
M.HEALTHSTONE_IDS = { 22105, 22104, 22103, 22102, 19013 }

--- Find the first ready healthstone in the player's inventory.
---@param me table Player unit object.
---@return number|nil item_id The first ready healthstone ID, or nil.
function M.find_ready_healthstone(me)
    if not me then return nil end
    for _, id in ipairs(M.HEALTHSTONE_IDS) do
        local cd_ok, cd_remaining = pcall(function()
            if NS.cooldown_remains then
                return NS.cooldown_remains({ _meta = { ids = { id } } }, me)
            end
            return 0
        end)
        if cd_ok and (cd_remaining or 0) <= 0 then
            return id
        end
    end
    return nil
end

--- Try to use the first available item from a list.
--- Each call is pcall-wrapped for nil/throwing API safety.
---@param context table Rotation context (needs context.me).
---@param ids    table Array of item IDs to try, best-first.
---@return boolean true if an item was successfully used.
function M.try_use_potion(context, ids)
    if not NS or not NS.use_item_by_id then return false end
    for _, id in ipairs(ids) do
        local ok, used = pcall(NS.use_item_by_id, id, context and context.me)
        if ok and used then return true end
    end
    return false
end

return M
