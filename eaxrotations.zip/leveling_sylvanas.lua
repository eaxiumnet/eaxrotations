-- leveling_sylvanas.lua -- shared Leveling Module: helpers used by all 9 leveling rotations.
-- WHAT:   shared Leveling Module: helpers used by all 9 leveling rotations.
-- WHEN:   called per-frame by every leveling_sylvanas.lua spec Variant
-- WHY:    eliminates 9 duplicate scaffolding blocks across class leveling files
-- SAFETY: all helpers nil-guarded; no on_update side-effects
-- DECISION: pure helper consumed via require() by specs; no on_update side-effects.


-- Shared Leveling Module.
-- Provides common helpers for per-class leveling rotations:
--   - Context guard (solo/leveling playstyle)
--   - Wand execute (Shoot spell)
--   - Common state builder
--   - Generic strategy helpers
--
-- Usage in per-class leveling_sylvanas.lua:
--   local leveling = require("shared/leveling_sylvanas")
--   local guard = leveling.create_context_guard()
--   leveling.execute_wand(context)

local NS = _G.EaxRotations
if not NS then return nil end

local leveling = {}

-- ============================================================================
-- Constants
-- ============================================================================

--- Shoot/Wand spell ID (learned via wand training, usable by all classes)
leveling.WAND_SPELL_ID = 5019

local EMPTY_SETTINGS = {}

-- ============================================================================
-- Context guard
-- ============================================================================

--- Creates a context guard function that checks if leveling rotation should fire.
--- Returns a function(context) -> boolean
function leveling.create_context_guard()
    return function(context)
        if not context then return false end
        if context.is_solo == true or context.is_leveling == true then return true end
        -- Also allow if user explicitly selected leveling playstyle
        local settings = context.settings or EMPTY_SETTINGS
        return settings.playstyle == "leveling" or settings.active_playstyle == "leveling"
    end
end

-- ============================================================================
-- Wand execute
-- ============================================================================

--- Executes the Shoot/wand spell on the target.
--- Starts auto-attack once; does NOT spam Shoot every frame.
--- @param context table Rotation context
--- @return boolean success
function leveling.execute_wand(context)
    if not context or not context.target then return false end
    if not NS.is_auto_attacking then
        -- Fallback: no auto-attack API available, use try_cast
        if NS.try_cast then
            return NS.try_cast(leveling.WAND_SPELL_ID, context.target, "[LEVELING] Wand") == true
        end
        return false
    end
    if NS.is_auto_attacking(context.me) then return true end
    return NS.start_auto_attack(context.target, NS.AUTO_ATTACK_WAND) == true
end

-- ============================================================================
-- Wand match function
-- ============================================================================

--- Creates a wand match function that checks mana threshold and spell readiness.
--- @param threshold_key string Setting key for wand mana threshold (e.g. "leveling_wand_threshold")
--- @param default_threshold number Default threshold if setting not found (default 30)
--- @return function matches(context, state) -> boolean
function leveling.create_wand_matches(threshold_key, default_threshold)
    local threshold = default_threshold or 30
    local key = threshold_key or "leveling_wand_threshold"

    return function(context, state)
        if not context then return false end
        if not state then return false end
        if not context.target then return false end
        if not state.wand_learned then return false end
        if not state.in_combat then return false end
        local mana_pct = state.mana_pct or 100
        local wand_threshold = state.wand_threshold or threshold
        if mana_pct >= wand_threshold then return false end
        return true
    end
end

-- ============================================================================
-- Generic state builder helpers
-- ============================================================================

--- Builds common state fields shared across all classes.
--- Call this from your per-class build_state() and then add class-specific fields.
--- @param context table Rotation context
--- @param state table The per-class state table to populate
--- @return table state (same as input, for chaining)
function leveling.build_common_state(context, state)
    if not context or not state then return state end

    state.in_combat = context.in_combat or false
    state.mana_pct = context.mana_pct or 100
    state.hp = context.hp or 100
    state.enemies = context.enemies_count or 0
    state.target = context.target
    state.is_moving = context.is_moving or false
    state.pet = context.pet

    -- Wand readiness (Shoot spell - wand training)
    local ok, exists = pcall(NS.spell_exists, leveling.WAND_SPELL_ID)
    state.wand_learned = ok and exists or false

    -- Read common settings
    local settings = context.settings or EMPTY_SETTINGS
    state.use_interrupt = settings.use_interrupt ~= false

    return state
end

-- ============================================================================
-- Generic interrupt match helper
-- ============================================================================

--- Creates a generic interrupt match function for a given spell readiness field.
--- @param state_field string Name of the spell readiness field in state (e.g. "counterspell_ready")
--- @return function matches(context, state) -> boolean
function leveling.create_interrupt_matches(state_field)
    return function(context, state)
        if not context then return false end
        if not state then return false end
        if not state.target then return false end
        if not state.use_interrupt then return false end
        if not state[state_field] then return false end
        local ok, casting = pcall(function() return state.target:is_casting() end)
        if not ok or not casting then return false end
        return true
    end
end

-- ============================================================================
-- Generic OOC buff match helper
-- ============================================================================

--- Creates a match function for out-of-combat self buffs.
--- Checks OOC status + buff missing + spell ready.
--- @param state_buff_field string State field indicating if buff is active (e.g. "has_fel_armor")
--- @param state_ready_field string State field indicating if spell is ready (e.g. "fel_armor_ready")
--- @return function matches(context, state) -> boolean
function leveling.create_ooc_buff_matches(state_buff_field, state_ready_field)
    return function(context, state)
        if not context then return false end
        if not state then return false end
        if state.in_combat then return false end
        if state[state_buff_field] then return false end
        if not state[state_ready_field] then return false end
        return true
    end
end

-- ============================================================================
-- Generic combat-or-target helper
-- ============================================================================

--- Safe combat check: returns true if in combat OR has a valid target.
-- Used by low-level rotations where combat state detection is unreliable.
-- Does NOT gate OOC buffs (those should still check in_combat).
function leveling.in_combat_or_has_target(context, state)
    if not context or not state then return false end
    if state.in_combat then return true end
    return state.target ~= nil
end

-- ============================================================================
-- Generic DoT refresh helper
-- ============================================================================

--- Checks if a DoT/debuff needs refreshing on the target.
--- @param target userdata Target game object
--- @param debuff_ids table Array of debuff spell IDs
--- @param refresh_time number Refresh threshold in seconds (default 4)
--- @return boolean needs_refresh
function leveling.dot_needs_refresh(target, debuff_ids, refresh_time)
    if not target then return false end
    local ok, remains = pcall(NS.debuff_remains, target, debuff_ids)
    local remaining = (ok and remains) or 0
    return remaining <= (refresh_time or 4)
end

-- ============================================================================
-- Generic AoE match helper
-- ============================================================================

--- Creates an AoE match function that fires when enough enemies are present.
--- @param min_enemies number Minimum enemy count (default 3)
--- @return function matches(context, state) -> boolean
function leveling.create_aoe_matches(min_enemies)
    local threshold = min_enemies or 3
    return function(context, state)
        if not context then return false end
        if not state then return false end
        if not state.target then return false end
        if not state.in_combat then return false end
        if (state.enemies or 0) < threshold then return false end
        if state.is_moving then return false end
        return true
    end
end

-- ============================================================================
-- Health Potion helpers
-- ============================================================================

--- Health Potion IDs (TBC, best to worst by level)
leveling.HEALTH_POTION_IDS = { 22829, 13446, 3928, 1710, 929, 858, 118 }

--- Match function for health potion usage.
-- Fires when in combat, HP below threshold, and a potion is available.
function leveling.health_potion_matches(context, state, threshold)
    if not context or not state then return false end
    if not state.in_combat then return false end
    local hp = state.hp or 100
    if hp > (threshold or 30) then return false end
    -- Check if any health potion is available
    if NS.is_item_ready then
        for _, id in ipairs(leveling.HEALTH_POTION_IDS) do
            local ok, ready = pcall(NS.is_item_ready, id)
            if ok and ready then return true end
        end
    end
    return false
end

--- Execute function for health potion usage.
-- Uses the best available health potion.
function leveling.health_potion_execute(context)
    if not NS.use_item_by_id then return false end
    for _, id in ipairs(leveling.HEALTH_POTION_IDS) do
        local ok, result = pcall(NS.use_item_by_id, id)
        if ok and result then return true end
    end
    return false
end

return leveling
