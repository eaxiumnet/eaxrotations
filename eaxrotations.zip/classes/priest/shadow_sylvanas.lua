-- shadow_sylvanas.lua — Priest Shadow DPS for TBC Anniversary (2.5.5).
-- WHAT:  DoT/caster DPS spec (VT, SW:P, Mind Blast, Mind Flay, SW:D execute)
--         with multi-DoT spread, snapshot-aware refresh, CC break, and
--         cooldown planning.
-- WHEN:  combat, with valid enemy target.
-- WHY:   mirrors wowsims APL: VT > SW:P > MB > SW:D (execute) > Mind Flay filler.
-- SAFETY: SW:D has safety_floor; Pattern 14 via spec_kit.safe_state(); _last_* throttles,
--         pcall requires, statics, nil-guards, context._*_target handoff, lockouts;
--         tracker wired (PR2) for _find + build_state counts with legacy fallback + setting gate.
--         General: other specs can pcall require shared/active_fight_tracker_sylvanas and call
--         get_active_fights / find_undotted_target / count for their multidot (engagement safe).
--         No on_update() allocs.
local NS = _G.EaxRotations
if not NS then return nil end

-- Hit-volume AoE gates (install if core not loaded, e.g. unit tests)
do
    local _ok_aoe, AoeHV = pcall(require, "shared/aoe_hit_volume_sylvanas")
    if _ok_aoe and AoeHV and AoeHV.install then AoeHV.install(NS) end
end
local SPELLS = NS.PriestSpells or {}
local spec_kit = require("shared/spec_kit_sylvanas")
local dsl = require("shared/strategy_dsl_sylvanas")

local mf_tick = require("shared/mf_tick_compute_sylvanas")

-- Centralized spell resolver via spec_kit (rank IDs from class_sylvanas.lua).
local define = spec_kit.define_action_for_class(SPELLS)
local ACTION = {
    ArcaneTorrent     = define("ArcaneTorrent",     { 25046 }, "ArcaneTorrent"),
    Berserking        = define("Berserking",        { 26297, 20554 }, "Berserking"),
    BloodFury         = define("BloodFury",         { 33697, 20572 }, "BloodFury"),
    DevouringPlague   = define("DevouringPlague",   { 25467, 19280, 19279, 19278, 19277, 19276, 2944 }, "DevouringPlague"),
    DispelMagic       = define("DispelMagic",       { 988, 527 }, "DispelMagic"),
    Fade              = define("Fade",              { 25429, 10942, 10941, 9592, 9579, 9578, 586 }, "Fade"),
    FlashHeal         = define("FlashHeal",         { 25235, 25233, 10917, 10916, 10915, 9474, 9473, 9472, 2061 }, "FlashHeal"),
    HolyNova          = define("HolyNova",          { 25331, 25329, 27805, 27804, 27803, 27801, 27800, 27799, 15431, 15430, 15237 }, "HolyNova"),
    InnerFire         = define("InnerFire",         { 25431, 10952, 10951, 1006, 602, 7128, 588 }, "InnerFire"),
    InnerFocus        = define("InnerFocus",        { 14751 }, "InnerFocus"),
    MindBlast         = define("MindBlast",         { 25375, 25372, 10947, 10946, 10945, 8106, 8105, 8104, 8103, 8102, 8092 }, "MindBlast"),
    MindFlay          = define("MindFlay",          { 25387, 18807, 17314, 17313, 17312, 17311, 15407 }, "MindFlay"),
    PowerWordFortitude= define("PowerWordFortitude",{ 25389, 10938, 10937, 2791, 1245, 1244, 1243 }, "PowerWordFortitude"),
    PowerWordShield   = define("PowerWordShield",   { 25218, 25217, 10901, 10900, 10899, 10898, 6066, 6065, 3747, 600, 592, 17 }, "PowerWordShield"),
    PsychicScream     = define("PsychicScream",     { 10890, 10888, 8124, 8122 }, "PsychicScream"),
    ShackleUndead     = define("ShackleUndead",     { 10955, 9485, 9484 }, "ShackleUndead"),
    ShadowWordDeath   = define("ShadowWordDeath",   { 32996, 32379 }, "ShadowWordDeath"),
    ShadowWordPain    = define("ShadowWordPain",    { 25368, 25367, 10894, 10893, 10892, 2767, 992, 970, 594, 589 }, "ShadowWordPain"),
    Shadowfiend       = define("Shadowfiend",       { 34433 }, "Shadowfiend"),
    Shadowform        = define("Shadowform",        { 15473 }, "Shadowform"),
    Starshards        = define("Starshards",        { 25446, 19305, 19304, 19303, 19302, 19299, 19296, 10797 }, "Starshards"),
    VampiricEmbrace   = define("VampiricEmbrace",   { 15286 }, "VampiricEmbrace"),
    VampiricTouch     = define("VampiricTouch",     { 34917, 34916, 34914 }, "VampiricTouch"),
}

local CCBreakDB = NS.OffensiveDispelDB or require("shared/offensive_dispel_sylvanas")
local DotTTD = require("shared/dot_ttd_gating_sylvanas")
local BuffHelper = require("shared/buff_manager_helper_sylvanas")
local _planner_ok, planner = pcall(require, "shared/cooldown_planner_sylvanas")
if not _planner_ok or type(planner) ~= "table" then planner = nil end
local _snap_ok, Snapshot = pcall(require, "shared/snapshot_sylvanas")
if not _snap_ok or type(Snapshot) ~= "table" then Snapshot = nil end
local _tracker_ok, ActiveFightTracker = pcall(require, "shared/active_fight_tracker_sylvanas")
if not _tracker_ok or type(ActiveFightTracker) ~= "table" then ActiveFightTracker = nil end
local _ts_ok, TSHelper = pcall(require, "shared/ts_helper_sylvanas")
if not _ts_ok or type(TSHelper) ~= "table" then TSHelper = nil end
local _last_shadow_cc_scan = 0
local _last_multidot_scan = 0
local _cached_dotted_swp = 0
local _cached_enemies_missing_swp = 0
local _cached_dotted_vt = 0
local _cached_enemies_missing_vt = 0

local function scan_target_debuffs(target)
    if not target then return {} end
    local rows = BuffHelper.get_all_debuffs(target, 50)
    if not rows or type(rows) ~= "table" then return {} end
    local out = {}
    for _, row in ipairs(rows) do
        local id = row and (row.buff_id or row.spell_id or row.id)
        if id and row.remaining and row.remaining > 0 then
            out[id] = row.remaining / 1000
        end
    end
    return out
end

local function debuff_remains_from_scan(target, scan, ids)
    if not ids then return 0 end
    if scan then
        for _, id in ipairs(ids) do
            if scan[id] then return scan[id] end
        end
    end
    -- Fallback: if the bulk buff_manager cache is empty/unavailable, use the
    -- standard NS.debuff_remains path so DoTs are not treated as expired.
    if target and NS.debuff_remains then
        local ok, remains = pcall(NS.debuff_remains, target, ids)
        if ok and type(remains) == "number" and remains > 0 then
            return remains
        end
    end
    return 0
end

-- ============================================================================
-- Buff & Debuff ID tables
-- ============================================================================
local SHADOWFORM_BUFF = { 15473 }
local INNER_FIRE_BUFF = { 25431, 10952, 10951, 1006, 602, 7128, 588 }
local WEAKENED_SOUL_DEBUFF = { 6788 }
local POWER_WORD_SHIELD_SPELL = { 25218, 25217, 10901, 10900, 10899, 10898, 6066, 6065, 3747, 600, 592, 17 }
local FLASH_HEAL_SPELL = { 25235, 25233, 10917, 10916, 10915, 9474, 9473, 9472, 2061 }
local INNER_FOCUS_BUFF = { 14751 }
local VAMPIRIC_TOUCH_DEBUFF = { 34917, 34916, 34914 }
local SHADOW_WORD_PAIN_DEBUFF = { 25368, 25367, 10894, 10893, 10892, 2767, 992, 970, 594, 589 }
local VAMPIRIC_EMBRACE_DEBUFF = { 15286 }
local MIND_FLAY_IDS = { 25387, 18807, 17314, 17313, 17312, 17311, 15407 }
local DEVOURING_PLAGUE_DEBUFF = { 25467, 19280, 19279, 19278, 19277, 19276, 2944 }
local SHADOW_WEAVING_DEBUFF = { 15258 }  -- Shadow Weaving talent debuff (5-stack +2% shadow dmg/stack)
local PSYCHIC_SCREAM_BUFF = { 10890, 10888, 8124, 8122 }
local STARSHARDS_SPELL = { 25446, 19305, 19304, 19303, 19302, 19299, 19296, 10797 }
local HOLY_NOVA_SPELL = { 25331, 25329, 27805, 27804, 27803, 27801, 27800, 27799, 15431, 15430, 15237 }

local SILENCE_INTERRUPT_SPELL = { 15487 }          -- Shadow talent Silence (15pt, interrupt)

-- Long cooldown TTD gating thresholds (seconds)
local SHADOWFIEND_CD = 300
local INNER_FOCUS_CD = 180
local MIN_TTD_FOR_CD_SHADOWFIEND = 60     -- Don't summon if combat ends within 60s (won't get 2nd use)
local MIN_TTD_FOR_CD_INNER_FOCUS = 45     -- Don't burn Inner Focus if combat ends within 45s

-- ============================================================================
-- Configurable DoT refresh windows
-- ============================================================================
local function vt_clip_threshold(context)
    return spec_kit.setting_number(context, "shadow_vt_refresh_window", 1.5)
end

local function swp_clip_threshold(context)
    return spec_kit.setting_number(context, "shadow_swp_refresh_window", 1.5)
end

-- Snapshot-aware refresh constants
local SPELL_DMG_UPGRADE_RATIO = 1.08    -- Refresh only if 8%+ spell damage upgrade
local BLOODLUST_LOWER_RATIO = 1.04      -- More aggressive upgrade threshold during Bloodlust/Heroism
local BLOODLUST_BUFFS = { 2825, 32182 }  -- Bloodlust (Horde) / Heroism (Alliance)
local REFRESH_EXTRA_WINDOW = 1.5         -- Extra seconds past pandemic window for upgrade refresh

-- Per-target cast lockout: prevents double-queuing a DoT to the same target
-- while a cast is in flight (matching parity's lockout tracking)
local _cast_lockouts = {}  -- guid -> { spell_name = true, expires = time_ms }

local function _set_lockout(spell_name, duration_ms, target)
    target = target or (NS.GetTarget and NS.GetTarget())
    if not target then return end
    local guid = target.get_guid and target:get_guid()
    if not guid then return end
    _cast_lockouts[guid] = _cast_lockouts[guid] or {}
    _cast_lockouts[guid][spell_name] = (NS.game_time_ms and NS.game_time_ms() or 0) + duration_ms
end

local function _is_locked(spell_name, target)
    target = target or (NS.GetTarget and NS.GetTarget())
    if not target then return false end
    local guid = target.get_guid and target:get_guid()
    if not guid or not _cast_lockouts[guid] then return false end
    local expires = _cast_lockouts[guid][spell_name]
    if not expires then return false end
    if (NS.game_time_ms and NS.game_time_ms() or 0) >= expires then
        _cast_lockouts[guid][spell_name] = nil
        return false
    end
    return true
end

local function target_creature_type(unit)
    if not unit then return nil end
    if type(NS.unit_creature_type) == "function" then return NS.unit_creature_type(unit) end
    if unit.get_creature_type then
        local ok, value = pcall(function() return unit:get_creature_type() end)
        if ok then return value end
    end
    return nil
end

-- ============================================================================
-- Multi-DoT target picker
-- ============================================================================
-- Returns the first nearby enemy that does NOT have any of the given debuff IDs.
-- Used so SW:P/VT spread/cleave strategies actually hit a missing target instead
-- of recasting on context.target (which already has the DoT).
-- Priority: TSHelper.get_dps_targets (target_selector) → ActiveFightTracker
-- (engagement-aware, GUID model, setting-gated) → legacy GetEnemiesInRange.
local function _find_multidot_target(context, debuff_ids, range)
    local current = context and context.target
    local function is_valid_target(enemy)
        if not enemy then return false end
        local ok, valid = pcall(function() return enemy.is_valid and enemy:is_valid() end)
        if ok and valid then return true end
        -- Fallback for test stubs / raw tables without unit API
        return ok == false and false or true
    end
    -- Prefer an enemy that is NOT the current target first (real spread)
    local function pick_undotted(enemies)
        if type(enemies) ~= "table" or #enemies == 0 then return nil end
        for pass = 1, 2 do
            for _, enemy in ipairs(enemies) do
                if is_valid_target(enemy) then
                    local is_current = current and NS.same_unit and NS.same_unit(enemy, current)
                    if pass == 1 and is_current then
                        -- skip current target on first pass
                    elseif not NS.debuff_up(enemy, debuff_ids) then
                        return enemy
                    end
                end
            end
        end
        return nil
    end

    -- 1) Primary: target_selector via TSHelper (scored DPS targets)
    if TSHelper and TSHelper.get_dps_targets then
        local ts_targets = TSHelper.get_dps_targets(10)
        local t = pick_undotted(ts_targets)
        if t then return t end
    end

    -- 2) ActiveFightTracker (engagement-aware; setting-gated)
    local use_tracker = true
    if context then
        use_tracker = spec_kit.setting_bool(context, "shadow_multidot_maintenance", true)
    end
    if use_tracker and ActiveFightTracker and ActiveFightTracker.find_undotted_target then
        local ok, t = pcall(ActiveFightTracker.find_undotted_target, context, debuff_ids, range)
        if ok and t then return t end
    end

    -- 3) Legacy fallback (raw GetEnemiesInRange path)
    if not context or not NS.GetEnemiesInRange then return nil end
    range = range or spec_kit.setting_number(context, "shadow_multidot_range", 30)
    return pick_undotted(NS.GetEnemiesInRange(range))
end

-- ============================================================================
-- State builder
-- ============================================================================
-- ============================================================================
-- Schema for safe_state (Pattern 14 nil-guard elimination).
local SHADOW_SCHEMA = {
    -- Channeling / filler state
    mf_channeling = false,
    mf_ticks = 0,
    should_clip_mf = false,
    -- DoT remains
    vt_remaining = 0,
    swp_remaining = 0,
    ve_remaining = 0,
    dp_remaining = 0,
    -- Spell readiness
    mb_ready = false,
    mb_cd_remains = 0,
    swd_ready = false,
    psychic_scream_ready = false,
    silence_ready = false,
    dispel_magic_ready = false,
    shackle_undead_ready = false,
    fade_ready = false,
    healthstone_ready = false,
    fortitude_ready = false,
    -- Spell known
    shadowform_known = false,
    shadowfiend_known = false,
    vampiric_touch_known = false,
    swp_known = false,
    vampiric_embrace_known = false,
    devouring_plague_known = false,
    mind_flay_known = false,
    inner_fire_known = false,
    flash_heal_known = false,
    berserking_known = false,
    blood_fury_known = false,
    arcane_torrent_known = false,
    starshards_known = false,
    wand_learned = false,
    -- Buff / debuff state
    has_shadowform = false,
    has_inner_focus = false,
    has_inner_fire = false,
    has_weakened_soul = false,
    has_bloodlust = false,
    has_fade_buff = false,
    has_fortitude = false,
    -- Combat state
    combat_mode = "auto",
    in_combat = false,
    enemy_count = 1,
    target_hp_pct = 100,
    target_casting = false,
    is_wanding = false,
    mounted = false,
    -- Configurable thresholds (populated from settings)
    vt_refresh_window = 3,
    swp_refresh_window = 3,
    dp_refresh_window = 3,
    swd_safety_hp = 80,
    shield_hp = 35,
    flash_heal_hp = 25,
    -- Mana management
    mana_pct = 100,
    hp_pct = 100,
    mana_low = false,
    mana_emergency = false,
    -- Threat
    threat_safe = true,
    -- Weaving
    weaving_stacks = 0,
    -- CC Break state
    has_breakable_cc = false,
    enemy_casting_cc = false,
    -- Snapshot state
    spell_damage = 0,
    snapshot_vt_dmg = 0,
    snapshot_swp_dmg = 0,
    snapshot_dp_dmg = 0,
    -- Cooldown awareness
    major_cd_window = false,
    bloodlust_active = false,
    -- Multi-DoT
    multidot_mode = 1,
    multidot_max = 3,
    dotted_swp_count = 0,
    enemies_missing_swp = 0,
    dotted_vt_count = 0,
    enemies_missing_vt = 0,
    -- Buffing
    is_group = false,
}

local shadow_state = {
    mf_channeling = false,
    mf_ticks = 0,
    should_clip_mf = false,
    vt_remaining = 0,
    swp_remaining = 0,
    ve_remaining = 0,
    dp_remaining = 0,
    mb_ready = false,
    swd_ready = false,
    has_shadowform = false,
    shadowform_known = false,
    shadowfiend_known = false,
    vampiric_touch_known = false,
    swp_known = false,
    vampiric_embrace_known = false,
    devouring_plague_known = false,
    mind_flay_known = false,
    inner_fire_known = false,
    flash_heal_known = false,
    berserking_known = false,
    blood_fury_known = false,
    arcane_torrent_known = false,
    starshards_known = false,
    has_inner_focus = false,
    has_inner_fire = false,
    combat_mode = "auto",          -- "auto" | "st" | "cleave" | "aoe"
    vt_refresh_window = 3,
    swp_refresh_window = 3,
    dp_refresh_window = 3,
    swd_safety_hp = 80,
    shield_hp = 35,
    flash_heal_hp = 25,
    mounted = false,
    psychic_scream_ready = false,
    silence_ready = false,
    dispel_magic_ready = false,
    shackle_undead_ready = false,
    mana_pct = 100,
    hp_pct = 100,
    in_combat = false,
    enemy_count = 1,
    target_hp_pct = 100,
    target_casting = false,
    target_creature_type = nil,
    -- Debuff tracking on target
    weaving_stacks = 0,                     -- Shadow Weaving stacks (0-5)
    -- Threat & mana safety gates
    threat_safe = true,                     -- Tank threat lead sufficient for burst
    mana_low = false,                       -- Mana below MB floor (drop Mind Blast)
    mana_emergency = false,                 -- Mana below emergency floor (wand only)
    -- SW:D CC Break state
    has_breakable_cc = false,               -- Player under damage-breakable CC (Poly/Gouge/Blind/Sap)
    breakable_cc_name = nil,                 -- Name of the CC effect
    enemy_casting_cc = false,               -- Enemy is casting a preemptive CC on player
    enemy_cc_spell_name = nil,              -- Name of the CC being cast
    -- Snapshot state (spell damage when DoT was applied)
    spell_damage = 0,
    snapshot_vt_dmg = 0,
    snapshot_swp_dmg = 0,
    snapshot_dp_dmg = 0,
    has_bloodlust = false,               -- Bloodlust/Heroism buff â€” enables more aggressive snapshot upgrades
    snapshot_target = nil,
    -- Wand/auto-attack state
    wand_learned = false,             -- Shoot (5019) is learned (wand equipped)
    is_wanding = false,               -- Currently auto-attacking with wand
    -- Out-of-combat buffing
    fortitude_ready = false,          -- Power Word: Fortitude is ready to cast
    has_fortitude = false,            -- Self has Fortitude buff
    fortitude_target = nil,           -- Party member (or self) missing Fortitude
    is_group = false,                 -- Player is in a group
    -- Multi-DoT state
    multidot_mode = 1,                -- 1=Off, 2=Near Target, 3=All in Range
    multidot_max = 3,                 -- Max targets for multidot
    multidot_range = 30,              -- Scan range for multidot
    dotted_swp_count = 0,             -- Enemies with SW:P
    enemies_missing_swp = 0,          -- Enemies without SW:P
    dotted_vt_count = 0,              -- Enemies with VT
    enemies_missing_vt = 0,           -- Enemies without VT
    mb_cd_remains = 0,                -- Mind Blast cooldown remaining
    -- Healthstone
    healthstone_id = nil,
    healthstone_ready = false,
    -- Fade
    fade_ready = false,
    has_fade_buff = false,
}

local function build_state(context)
    local target = context.target
    local me = NS.GetPlayer()
    if not me then return spec_kit.safe_state(shadow_state, SHADOW_SCHEMA) end
    if spec_kit.setting_bool(context, "shadow_mounted_bail", true) then
        if me.is_mounted and me:is_mounted() then
            shadow_state.mounted = true
            return spec_kit.safe_state(shadow_state, SHADOW_SCHEMA)
        end
    end
    shadow_state.mounted = false
    
    local debuff_scan = target and scan_target_debuffs(target) or {}
    shadow_state.vt_remaining = debuff_remains_from_scan(target, debuff_scan, VAMPIRIC_TOUCH_DEBUFF)
    shadow_state.swp_remaining = debuff_remains_from_scan(target, debuff_scan, SHADOW_WORD_PAIN_DEBUFF)
    shadow_state.ve_remaining = debuff_remains_from_scan(target, debuff_scan, VAMPIRIC_EMBRACE_DEBUFF)
    shadow_state.dp_remaining = debuff_remains_from_scan(target, debuff_scan, DEVOURING_PLAGUE_DEBUFF)
    shadow_state.mb_ready = target and NS.spell_ready(ACTION.MindBlast, target, { expected_cooldown = 5.5 }) or false
    shadow_state.mb_cd_remains = NS.cooldown_remains and NS.cooldown_remains(ACTION.MindBlast) or 0
    shadow_state.swd_ready = target and NS.spell_ready(ACTION.ShadowWordDeath, target, { expected_cooldown = 12 }) or false
    shadow_state.mf_channeling, shadow_state.mf_ticks = mf_tick.compute_channel_state(me, NS.game_time_ms(), MIND_FLAY_IDS)
    shadow_state.should_clip_mf = mf_tick.should_clip_mf(
        shadow_state.mf_channeling,
        shadow_state.mf_ticks,
        vt_clip_threshold(context),
        shadow_state.mb_ready,
        shadow_state.swd_ready,
        shadow_state.vt_remaining,
        shadow_state.swp_remaining,
        swp_clip_threshold(context)
    )
    shadow_state.has_shadowform = me and NS.buff_up(me, SHADOWFORM_BUFF) or false
    shadow_state.shadowform_known = me and NS.spell_exists and NS.spell_exists(ACTION.Shadowform) or false
    shadow_state.shadowfiend_known = me and NS.spell_exists and NS.spell_exists(ACTION.Shadowfiend) or false
    shadow_state.vampiric_touch_known = me and NS.spell_exists and NS.spell_exists(ACTION.VampiricTouch) or false
    shadow_state.swp_known = me and NS.spell_exists and NS.spell_exists(ACTION.ShadowWordPain) or false
    shadow_state.vampiric_embrace_known = me and NS.spell_exists and NS.spell_exists(ACTION.VampiricEmbrace) or false
    shadow_state.devouring_plague_known = me and NS.spell_exists and NS.spell_exists(ACTION.DevouringPlague) or false
    shadow_state.mind_flay_known = me and NS.spell_exists and NS.spell_exists(ACTION.MindFlay) or false
    shadow_state.inner_fire_known = me and NS.spell_exists and NS.spell_exists(ACTION.InnerFire) or false
    shadow_state.flash_heal_known = me and NS.spell_exists and NS.spell_exists(ACTION.FlashHeal) or false
    shadow_state.berserking_known = me and NS.spell_exists and NS.spell_exists(ACTION.Berserking) or false
    shadow_state.blood_fury_known = me and NS.spell_exists and NS.spell_exists(ACTION.BloodFury) or false
    shadow_state.arcane_torrent_known = me and NS.spell_exists and NS.spell_exists(ACTION.ArcaneTorrent) or false
    shadow_state.starshards_known = me and NS.spell_exists and NS.spell_exists(ACTION.Starshards) or false
    shadow_state.has_inner_focus = me and NS.buff_up(me, INNER_FOCUS_BUFF) or false
    shadow_state.has_inner_fire = me and NS.buff_up(me, INNER_FIRE_BUFF) or false
    -- Combat mode: explicit setting or auto-detect
    local mode = spec_kit.setting(context, "shadow_combat_mode", "auto")
    if mode == "auto" then
        local enemy_count = shadow_state.enemy_count or 0
        if enemy_count >= 5 then mode = "aoe"
        elseif enemy_count >= 3 then mode = "cleave"
        else mode = "st" end
    end
    shadow_state.combat_mode = mode
    -- Configurable refresh windows
    shadow_state.vt_refresh_window = spec_kit.setting_number(context, "shadow_vt_refresh_window", 1.5)
    shadow_state.swp_refresh_window = spec_kit.setting_number(context, "shadow_swp_refresh_window", 1.5)
    shadow_state.dp_refresh_window = spec_kit.setting_number(context, "shadow_dp_refresh_window", 3)
    -- Configurable safety thresholds
    shadow_state.swd_safety_hp = spec_kit.setting_number(context, "shadow_swd_safety_hp", 80)
    shadow_state.shield_hp = spec_kit.setting_number(context, "shadow_shield_hp", 35)
    shadow_state.flash_heal_hp = spec_kit.setting_number(context, "shadow_flash_heal_hp", 25)
    -- Multi-DoT settings
    shadow_state.multidot_mode = spec_kit.setting_number(context, "shadow_multidot_mode", 1)
    shadow_state.multidot_max = spec_kit.setting_number(context, "shadow_multidot_max_targets", 3)
    shadow_state.multidot_range = spec_kit.setting_number(context, "shadow_multidot_range", 30)
    -- Has Weakened Soul (cannot receive PW:Shield)
    shadow_state.has_weakened_soul = me and NS.debuff_up and NS.debuff_up(me, WEAKENED_SOUL_DEBUFF) or false
    
    shadow_state.silence_ready = me and NS.spell_ready(SILENCE_INTERRUPT_SPELL, target, { expected_cooldown = 45 }) or false
    shadow_state.psychic_scream_ready = me and NS.spell_ready(ACTION.PsychicScream, me, { skip_range = true, expected_cooldown = 30 }) or false
    shadow_state.dispel_magic_ready = me and NS.spell_ready(ACTION.DispelMagic, me, { skip_range = true }) or false
    shadow_state.shackle_undead_ready = me and NS.spell_ready(ACTION.ShackleUndead, me, { expected_cooldown = 1.5 }) or false
    shadow_state.mana_pct = context.mana_pct or (me and NS.unit_mana_pct(me)) or 100
    shadow_state.hp_pct = context.hp or (me and NS.unit_health_pct(me)) or 100

    -- Shadow Weaving debuff stacks on target
    shadow_state.weaving_stacks = target and NS.get_debuff_stacks and NS.get_debuff_stacks(target, SHADOW_WEAVING_DEBUFF) or 0

    -- Mana conservation floors (from Research: <30% drop MB, <15% wand only)
    local mb_mana_floor = spec_kit.setting_number(context, "shadow_mb_mana_floor", 30)
    local conserve_mana_floor = spec_kit.setting_number(context, "shadow_conserve_mana_floor", 15)
    shadow_state.mana_low = shadow_state.mana_pct < mb_mana_floor
    shadow_state.mana_emergency = shadow_state.mana_pct < conserve_mana_floor

    -- SW:D CC Break: check if player is under breakable CC or enemy is casting CC on player
    -- Gated behind settings to avoid wasted PvE cycles
    shadow_state.has_breakable_cc = false
    shadow_state.breakable_cc_name = nil
    shadow_state.enemy_casting_cc = false
    shadow_state.enemy_cc_spell_name = nil
    if spec_kit.setting_bool(context, "shadow_swd_cc_break", true) then
        shadow_state.has_breakable_cc, shadow_state.breakable_cc_name = CCBreakDB.is_breakable_cc_active(me, NS)
        if not shadow_state.has_breakable_cc then
            -- Preemptive scan: check if any nearby enemy is casting a CC on us
            -- Throttled to avoid per-frame enemy iteration
            local now = NS.time_now and NS.time_now() or 0
            if now - (_last_shadow_cc_scan or 0) >= 0.3 then
                _last_shadow_cc_scan = now
                -- This is the primary SW:D CC break path â€” casting SW:D preemptively
                -- triggers backlash damage that will break incoming CC if it lands
                local enemies = NS.GetEnemiesInRange and NS.GetEnemiesInRange(30) or {}
                for _, enemy in ipairs(enemies) do
                    if enemy then
                        local is_casting_cc, cc_name = CCBreakDB.is_casting_preemptive_cc(enemy)
                        if is_casting_cc then
                            -- Check if this enemy is targeting the player
                            local ok, etarget = pcall(function() return enemy:get_target() end)
                            if ok and etarget and NS.same_unit and NS.same_unit(etarget, me) then
                                shadow_state.enemy_casting_cc = true
                                shadow_state.enemy_cc_spell_name = cc_name
                                break
                            end
                        end
                    end
                end
            end
        end
    end

    -- Threat safety: gate burst behind tank threat lead
    -- Uses NS.is_threat_safe if available, otherwise assumes safe
    local threat_safe_enabled = spec_kit.setting_bool(context, "shadow_threat_safe", true)
    if threat_safe_enabled and NS.is_threat_safe then
        shadow_state.threat_safe = NS.is_threat_safe(context)
    else
        shadow_state.threat_safe = true
    end
    shadow_state.in_combat = context.in_combat or false
    shadow_state.enemy_count = context.enemy_count or context.enemies_count or 1
    shadow_state.target_hp_pct = target and NS.unit_health_pct and NS.unit_health_pct(target) or 100
    shadow_state.target_casting = target and target.is_casting and target:is_casting() or false
    shadow_state.target_creature_type = target_creature_type(target)
    
    -- Wand readiness (Shoot spell - wand training)
    shadow_state.wand_learned = NS.spell_exists and NS.spell_exists(5019) or false
    shadow_state.is_wanding = shadow_state.wand_learned and NS.is_auto_attacking and NS.is_auto_attacking(context.me) or false
    
    -- Fortitude buff readiness (party-aware)
    local me_unit = context.me or me
    local FORTITUDE_BUFFS = { 25392, 21564, 21562, 39231, 25389, 10938, 10937, 2791, 1245, 1244, 1243 }
    shadow_state.fortitude_ready = me_unit and NS.spell_ready and NS.spell_ready(ACTION.PowerWordFortitude, me_unit, { skip_range = true }) or false
    shadow_state.has_fortitude = me_unit and NS.buff_up and NS.buff_up(me_unit, FORTITUDE_BUFFS) or false
    shadow_state.is_group = context.is_group or false
    -- Scan party members for missing Fortitude (in-range only); fallback to self
    shadow_state.fortitude_target = nil
    if shadow_state.fortitude_ready then
        local members = context.party_members or context.group_members
        if type(members) == "table" and #members > 0 then
            for i = 1, #members do
                local member = members[i]
                if member and not (NS.buff_up and NS.buff_up(member, FORTITUDE_BUFFS)) then
                    -- Range gate: PW:F is a 40yd single-target buff. Skip out-of-range
                    -- members so we don't lock onto someone across the zone and stall the
                    -- self-buff fallback. is_spell_in_range nil-guarded for test harness.
                    local in_range = (not NS.is_spell_in_range)
                        or NS.is_spell_in_range(ACTION.PowerWordFortitude, member) == true
                    if in_range then
                        shadow_state.fortitude_target = member
                        break
                    end
                end
            end
        end
        if not shadow_state.fortitude_target and not shadow_state.has_fortitude then
            shadow_state.fortitude_target = me_unit
        end
    end

    -- Current spell damage from NS (provided by middleware or character API)
    shadow_state.spell_damage = context.spell_damage or 0
    -- Bloodlust/Heroism buff â€” enables more aggressive snapshot upgrade threshold
    shadow_state.has_bloodlust = me and NS.buff_up(me, BLOODLUST_BUFFS) or false
    -- Multi-DoT: scan nearby enemies for missing DoTs (throttled to 1s)
    -- PR2: uses tracker.get_active_fights (when gate+available) for engaged-only counts; legacy raw as fallback.
    -- State fields always populated for UI/tests/compat regardless of path.
    shadow_state.dotted_swp_count = 0
    shadow_state.enemies_missing_swp = 0
    shadow_state.dotted_vt_count = 0
    shadow_state.enemies_missing_vt = 0
    local now_t = NS.time_now and NS.time_now() or 0
    if (now_t - _last_multidot_scan) >= 1.0 then
        _last_multidot_scan = now_t
        if shadow_state.in_combat and shadow_state.enemy_count >= 2 then
            -- Setting gate (default on) + tracker path for counts
            local use_tracker = spec_kit.setting_bool(context, "shadow_multidot_maintenance", true)
            local enemies = {}
            if use_tracker and ActiveFightTracker and ActiveFightTracker.get_active_fights then
                local ok, f = pcall(ActiveFightTracker.get_active_fights, shadow_state.multidot_range or 30)
                enemies = (ok and f) or {}
            else
                enemies = NS.GetEnemiesInRange and NS.GetEnemiesInRange(shadow_state.multidot_range) or {}
            end
            local swp_missing = 0
            local swp_dotted = 0
            local vt_missing = 0
            local vt_dotted = 0
            local cnt = (enemies and (enemies.n or #enemies)) or 0
            for i = 1, cnt do
                local enemy = enemies[i]
                if enemy then
                    local has_swp = NS.debuff_up and NS.debuff_up(enemy, SHADOW_WORD_PAIN_DEBUFF) or false
                    local has_vt = NS.debuff_up and NS.debuff_up(enemy, VAMPIRIC_TOUCH_DEBUFF) or false
                    if has_swp then swp_dotted = swp_dotted + 1 else swp_missing = swp_missing + 1 end
                    if has_vt then vt_dotted = vt_dotted + 1 else vt_missing = vt_missing + 1 end
                end
            end
            _cached_dotted_swp = swp_dotted
            _cached_enemies_missing_swp = swp_missing
            _cached_dotted_vt = vt_dotted
            _cached_enemies_missing_vt = vt_missing
        end
    end
    shadow_state.dotted_swp_count = _cached_dotted_swp
    shadow_state.enemies_missing_swp = _cached_enemies_missing_swp
    shadow_state.dotted_vt_count = _cached_dotted_vt
    shadow_state.enemies_missing_vt = _cached_enemies_missing_vt
    -- Maintain snapshot state: reset snapshots if DoT expired or target changed
    local target_key = target and (target.get_guid and target:get_guid()) or nil
    if target_key ~= shadow_state.snapshot_target then
        shadow_state.snapshot_vt_dmg = 0
        shadow_state.snapshot_swp_dmg = 0
        shadow_state.snapshot_dp_dmg = 0
        shadow_state.snapshot_target = target_key
    else
        if shadow_state.vt_remaining <= 0 then shadow_state.snapshot_vt_dmg = 0 end
        if shadow_state.swp_remaining <= 0 then shadow_state.snapshot_swp_dmg = 0 end
        if shadow_state.dp_remaining <= 0 then shadow_state.snapshot_dp_dmg = 0 end
    end

    -- Healthstone scanning
    shadow_state.healthstone_id = nil
    shadow_state.healthstone_ready = false
    if NS.is_item_ready then
        local HEALTHSTONE_IDS = { 22105, 22104, 22103, 22102, 22101, 22100 }
        for _, id in ipairs(HEALTHSTONE_IDS) do
            local ok, ready = pcall(NS.is_item_ready, id)
            if ok and ready then
                shadow_state.healthstone_id = id
                shadow_state.healthstone_ready = true
                break
            end
        end
    end

    -- Fade state
    shadow_state.fade_ready = me and NS.spell_ready(ACTION.Fade, me, { skip_range = true }) or false
    shadow_state.has_fade_buff = me and NS.buff_up(me, { 25429, 10942, 10941, 9592, 9579, 9578, 586 }) or false

    -- Major power-window awareness for racial/trinket alignment
    shadow_state.bloodlust_active = me and NS.buff_up and NS.buff_up(me, BLOODLUST_BUFFS) or false
    shadow_state.major_cd_active = planner and planner.is_major_offensive_cd_active(context) or false
    shadow_state.major_cd_window = shadow_state.bloodlust_active or shadow_state.major_cd_active

    return spec_kit.safe_state(shadow_state, SHADOW_SCHEMA)
end

-- ============================================================================
-- Snapshot upgrade logic
-- ============================================================================

-- Determine if current spell damage justifies refreshing a DoT early
-- Returns true if: DoT expired, in pandemic window with upgrade, or about to fall off
local function should_snapshot_upgrade(current_dmg, snapshotted_dmg, remains, refresh_window, ratio)
    -- Delegate to shared helper (preserves shadow behavior: no-snapshot -> refresh, extra_window 1.5)
    if Snapshot then
        return Snapshot.should_upgrade(current_dmg, snapshotted_dmg, remains, refresh_window, ratio,
            { no_snapshot_refresh = true, extra_window = REFRESH_EXTRA_WINDOW })
    end
    -- Inline fallback (identical to prior behavior)
    if remains <= 0 then return true end
    if remains <= refresh_window then return true end
    if snapshotted_dmg <= 0 then return true end
    if current_dmg >= snapshotted_dmg * ratio and remains <= refresh_window + REFRESH_EXTRA_WINDOW then
        return true
    end
    return false
end

local function can_break_mind_flay(s)
    return not s.mf_channeling or s.should_clip_mf
end

local function _engaged_with_player(context)
    -- Allow free pulling when out of combat; safety gate only applies in-combat
    if not context.in_combat then return true end
    local target = context.target
    local me = context.me
    if not target or not me then return true end
    if (context.target_hp or 100) < 100 then return true end
    local ok, enemy_target = pcall(function() return target:get_target() end)
    if not ok or not enemy_target then return false end
    if NS.same_unit and NS.same_unit(enemy_target, me) then return true end
    return false
end



-- ============================================================================
-- Match functions
-- ============================================================================
local function pre_combat_pull_matches(context, s)
    if context.in_combat then return false end
    if not context.has_valid_enemy_target then return false end
    if not s.has_shadowform then return false end
    -- Pull with Vampiric Touch (instant-cast DoT) if available, otherwise Mind Blast
    if NS.spell_ready and NS.spell_ready(ACTION.VampiricTouch, context.target, { skip_range = false }) then
        return true
    end
    return false
end

local function shadowfiend_matches(context, s)
    if not s.shadowfiend_known then return false end
    if not can_break_mind_flay(s) then return false end
    if not context.has_valid_enemy_target then return false end
    -- Wowsims-aligned Shadowfiend timing:
    -- Short fight (<120s): use early for mana return; mana% gate relaxed.
    -- Long fight: use when dots active and VT remaining >= Shadowfiend GCD (~1.5s).
    -- Emergency: always fire when mana critically low.
    local ttd = context.ttd or 999
    local short_fight = ttd < 120
    local long_fight = ttd >= 120
    local mana_low = (context.mana_pct or 100) <= 45
    local mana_emergency = (context.mana_pct or 100) <= 15
    local vt_active = (s.vt_remaining or 0) > 0
    local vt_long_enough = (s.vt_remaining or 0) >= 1.5
    if mana_emergency then return true end
    if short_fight and mana_low then return true end
    if long_fight and vt_active and vt_long_enough and mana_low then return true end
    -- Legacy fallback: fire at <45% if TTD allows
    if context.ttd_known and context.ttd > 0 and context.ttd < MIN_TTD_FOR_CD_SHADOWFIEND then return false end
    return false
end

local _cached_swp_spread_target = nil
local function shadow_swp_spread_matches(context, s)
    if not s.swp_known then return false end
    if not can_break_mind_flay(s) then return false end
    -- Combat mode gate: only spread in cleave or aoe mode
    if s.combat_mode ~= "cleave" and s.combat_mode ~= "aoe" then return false end
    if (s.enemy_count or 0) < 3 then return false end
    if not context.has_valid_enemy_target then return false end
    if not _engaged_with_player(context) then return false end
    -- Per-target lockout: prevent double-queuing SW:P to same target while in-flight
    if _is_locked("SWP") then return false end
    -- Obtain candidate via tracker (PR2 wire) or legacy _find; then remains/snapshot checks below (kept intact)
    local target = _find_multidot_target(context, SHADOW_WORD_PAIN_DEBUFF)
    if not target then return false end
    context._shadow_swp_spread_target = target
    -- Allow refresh on the picked target if it is currently active but snapshot-upgradeable or in pandemic
    local swp_window = s.swp_refresh_window or 3
    local swp_remains = NS.debuff_remains and NS.debuff_remains(target, SHADOW_WORD_PAIN_DEBUFF) or 0
    if swp_remains > 0 and swp_remains > swp_window then
        if not should_snapshot_upgrade(s.spell_damage, s.snapshot_swp_dmg, swp_remains, swp_window, SPELL_DMG_UPGRADE_RATIO) then
            return false
        end
    end
    return true
end

local _cached_vt_spread_target = nil
local function shadow_vt_spread_matches(context, s)
    if not s.vampiric_touch_known then return false end
    if not can_break_mind_flay(s) then return false end
    -- Combat mode gate: only spread in cleave or aoe mode
    if s.combat_mode ~= "cleave" and s.combat_mode ~= "aoe" then return false end
    if (s.enemy_count or 0) < 3 then return false end
    if not context.has_valid_enemy_target then return false end
    if not _engaged_with_player(context) then return false end
    -- Per-target lockout: prevent double-queuing VT to same target while in-flight
    if _is_locked("VT") then return false end
    -- Obtain candidate via tracker (PR2 wire) or legacy _find; then remains/snapshot checks below (kept intact)
    local target = _find_multidot_target(context, VAMPIRIC_TOUCH_DEBUFF)
    if not target then return false end
    context._shadow_vt_spread_target = target
    -- Allow refresh on the picked target if currently active but snapshot-upgradeable or in pandemic
    local vt_window = s.vt_refresh_window or 3
    local vt_remains = NS.debuff_remains and NS.debuff_remains(target, VAMPIRIC_TOUCH_DEBUFF) or 0
    if vt_remains > 0 and vt_remains > vt_window then
        if not should_snapshot_upgrade(s.spell_damage, s.snapshot_vt_dmg, vt_remains, vt_window, SPELL_DMG_UPGRADE_RATIO) then
            return false
        end
    end
    return true
end

local function power_word_shield_matches(context, s)
    -- HP-gated self-shield
    if (context.hp or 100) > (s.shield_hp or 35) then return false end
    -- Can't cast if Weakened Soul is active
    if s.has_weakened_soul then return false end
    if not (NS.spell_ready and NS.spell_ready(ACTION.PowerWordShield, NS.PLAYER_UNIT, { skip_range = true })) then return false end
    return true
end

local function flash_heal_matches(context, s)
    if not s.flash_heal_known then return false end
    -- HP-gated self-heal
    if (context.hp or 100) > (s.flash_heal_hp or 25) then return false end
    if context.is_moving then return false end
    return true
end

local function holy_nova_aoe_matches(context, s)
    -- Combat mode gate: only AoE in aoe mode
    if s.combat_mode ~= "aoe" then return false end
    if context.is_moving then return false end
    -- Holy Nova: 10yd self PBAoE (DBC) — do not use 40yd enemy_count
    if not NS.aoe_self_meets or not NS.aoe_self_meets(3, (NS.AOE_RADIUS and NS.AOE_RADIUS.SELF_10) or 10, context, s) then return false end
    if not context.in_combat then return false end
    return NS.spell_ready and NS.spell_ready(ACTION.HolyNova, context.target, nil)
end

local function racial_matches(context, s)
    if not can_break_mind_flay(s) then return false end
    if not context.has_valid_enemy_target then return false end
    if not context.in_combat then return false end
    if not s.berserking_known and not s.blood_fury_known and not s.arcane_torrent_known then return false end
    -- TTD gate: don't use racials if target is about to die
    if context.ttd_known and context.ttd > 0 and context.ttd < 8 then return false end
    -- Stack racials with major power windows; timeout fallback so they fire
    local align = s.major_cd_window or false
    local combat_time = context.combat_time or 0
    local ttd = context.ttd or 999
    if not align and combat_time < 45 and ttd > 15 then return false end
    return true
end

local function vampiric_embrace_matches(context, s)
    if not s.vampiric_embrace_known then return false end
    if not can_break_mind_flay(s) then return false end
    if not context.has_valid_enemy_target or s.ve_remaining > 10 then return false end
    if (s.ve_remaining or 0) <= 0 and not _engaged_with_player(context) then return false end
    return true
end

local function devouring_plague_matches(context, s)
    if not s.devouring_plague_known then return false end
    if NS.broken_api_throttled and NS.broken_api_throttled(ACTION.DevouringPlague, 2.0) then return false end
    if not can_break_mind_flay(s) then return false end
    if not context.has_valid_enemy_target or s.dp_remaining > (s.dp_refresh_window or 3) then return false end
    -- Mana emergency: drop all spells (wand only)
    if s.mana_emergency then return false end
    -- Snapshot-aware: hold refresh if current spell damage is not an upgrade over snapshotted
    local ratio = s.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
    if s.dp_remaining > 0 and not should_snapshot_upgrade(s.spell_damage, s.snapshot_dp_dmg, s.dp_remaining, 3, ratio) then return false end
    if (s.dp_remaining or 0) <= 0 and not _engaged_with_player(context) then return false end
    return true
end

local function inner_focus_matches(context, s)
    if not can_break_mind_flay(s) then return false end
    if not context.in_combat then return false end
    if s.has_inner_focus then return false end
    if s.mana_low then return false end  -- don't burn IF if MB is gated by mana
    -- Inner Focus + Mind Blast combo: hold IF for MB when both are ready or MB is off soon
    local combo_enabled = spec_kit.setting_bool(context, "shadow_if_mb_combo", true)
    if combo_enabled then
        -- If MB is ready now, queue IF immediately (next GCD will be MB)
        if s.mb_ready then return true end
        -- If MB is on short CD (<= 5s), hold IF for the combo
        if (s.mb_cd_remains or 999) <= 5 then return true end
        -- MB is on long CD (> 5s) â€” use IF on next best spell (don't hold forever)
        -- Fall through to non-combo logic below
    end
    -- Non-combo path (or combo disabled / MB on long CD): use IF when MB is off cooldown
    if not s.mb_ready then return false end
    -- TTD gate: don't burn 180s cooldown if combat ends within threshold
    if context.ttd_known and context.ttd > 0 and context.ttd < MIN_TTD_FOR_CD_INNER_FOCUS then return false end
    return true
end

-- ============================================================================
-- SW:D CC Break: preemptively break incoming CC via SW:D backlash damage
-- ============================================================================
-- PRIMARY PATH (enemy_casting_cc): When an enemy is casting Polymorph/Fear/Cyclone
--   on us, cast SW:D on the enemy. If the CC lands during SW:D's backlash window,
--   the self-damage tick breaks it.
--
-- FALLBACK PATH (has_breakable_cc): Player is already under damage-breakable CC.
--   In TBC, most CCs prevent casting, so this path is rarely reachable. It exists
--   as a safety net for edge cases (e.g., CC that doesn't block spell casts).
-- ============================================================================
local function swd_cc_break_matches(context, s)
    -- CC Break is exempt from MF clipping gate (must break CC immediately)
    if not s.swd_ready then return false end
    if not context.has_valid_enemy_target then return false end
    if not spec_kit.setting_bool(context, "shadow_swd_cc_break", true) then return false end
    -- Primary path: enemy is casting a CC on us â€” preempt with SW:D
    if s.enemy_casting_cc and s.enemy_cc_spell_name then
        return true
    end
    -- Fallback path: player is already under breakable CC (safety net)
    if s.has_breakable_cc and s.breakable_cc_name then
        return true
    end
    return false
end

local function mind_flay_matches(context, s)
    if not s.mind_flay_known then return false end
    if context.is_moving or context.is_casting or context.is_channeling then return false end
    if not context.has_valid_enemy_target then return false end
    -- Mana emergency: drop all spells (wand only)
    if s.mana_emergency then return false end
    if not _engaged_with_player(context) then return false end
    return true
end

local function silence_matches(context, s)
    if not can_break_mind_flay(s) then return false end
    if not context.in_combat then return false end
    if not s.silence_ready then return false end
    if not context.target or not NS.unit_interruptible then
        -- Fallback: check target casting state without native interruptible API
        if not context.target_is_casting then return false end
    end
    return true
end

local function psychic_scream_matches(context, s)
    if not context.in_combat then return false end
    if (s.enemy_count or 0) < 3 then return false end
    if not s.psychic_scream_ready then return false end
    return true
end

-- ============================================================================
-- Multi-DoT: spread SW:P and VT to nearby enemies in cleave/AoE
-- ============================================================================
local function multidot_swp_matches(context, s)
    local mode = s.multidot_mode or 1
    if mode == 1 then return false end  -- Off
    if not s.swp_known then return false end
    if not can_break_mind_flay(s) then return false end
    if not context.in_combat then return false end
    if not _engaged_with_player(context) then return false end
    if (s.enemy_count or 0) < 2 then return false end
    -- Only multidot when target HP > 30% (don't waste on dying adds)
    if (context.target_hp_pct or 100) <= 30 then return false end
    -- Limit to max targets
    if (s.dotted_swp_count or 0) >= (s.multidot_max or 3) then return false end
    -- Mana gate: don't spread below emergency
    if s.mana_emergency then return false end
    -- Obtain candidate via tracker (PR2 wire) or legacy _find; post-picker logic (remains, TTD, _engaged) kept
    local target = _find_multidot_target(context, SHADOW_WORD_PAIN_DEBUFF)
    if not target then return false end
    context._shadow_swp_spread_target = target
    return true
end

local function multidot_vt_matches(context, s)
    local mode = s.multidot_mode or 1
    if mode == 1 then return false end  -- Off
    if not s.vampiric_touch_known then return false end
    if not can_break_mind_flay(s) then return false end
    if not context.in_combat then return false end
    if not _engaged_with_player(context) then return false end
    if context.is_moving then return false end
    if (s.enemy_count or 0) < 2 then return false end
    -- Only multidot when target HP > 30% (don't waste on dying adds)
    if (context.target_hp_pct or 100) <= 30 then return false end
    -- Limit to max targets
    if (s.dotted_vt_count or 0) >= (s.multidot_max or 3) then return false end
    -- Mana emergency: drop all spells
    if s.mana_emergency then return false end
    -- Obtain candidate via tracker (PR2 wire) or legacy _find; post-picker logic (remains, TTD, _engaged) kept
    local target = _find_multidot_target(context, VAMPIRIC_TOUCH_DEBUFF)
    if not target then return false end
    context._shadow_vt_spread_target = target
    return true
end

local function dispel_magic_matches(context, s)
    -- Disabled: middleware PartyDispelMagic already handles self + party dispel
    -- with proper settings gating and debuff detection.
    -- This strategy was casting DispelMagic on self without checking for debuffs,
    -- wasting GCD on every frame.
    return false
end

local function shackle_undead_matches(context, s)
    if not context.has_valid_enemy_target then return false end
    if s.target_creature_type ~= 6 then return false end
    if not s.shackle_undead_ready then return false end
    if context.target and NS.debuff_up and NS.debuff_up(context.target, {9484, 9485, 10955}) then return false end
    return true
end

local function starshards_matches(context, s)
    if not s.starshards_known then return false end
    if not context.has_valid_enemy_target then return false end
    if context.is_moving then return false end
    if not _engaged_with_player(context) then return false end
    return true
end

-- ============================================================================
-- Wand / Auto-Attack (mana emergency â€” conserve_mana_floor)
-- ============================================================================
local function mana_emergency_wand_matches(context, s)
    if not s.mana_emergency then return false end
    if not context.in_combat then return false end
    if not context.has_valid_enemy_target then return false end
    if not s.wand_learned then return false end
    -- Only start if not already wanding (let existing auto-attack run)
    if NS.is_auto_attacking and NS.is_auto_attacking(context.me) then return true end
    return true
end

-- ============================================================================
-- Fortitude out-of-combat party buff
-- ============================================================================
local function fortitude_matches(context, s)
    if context.in_combat then return false end
    if not s.fortitude_ready then return false end
    if not s.fortitude_target then return false end
    return true
end

local function swd_cc_break_execute(context, s)
    if s.mf_channeling then
        if NS.stop_casting then NS.stop_casting() end
        if NS.cancel_current_cast then NS.cancel_current_cast() end
    end
    return NS.try_cast(ACTION.ShadowWordDeath, context.target, string.format("[SHADOW] SWD CC Break -> %s", s.enemy_cc_spell_name or s.breakable_cc_name or "CC"))
end

local function mana_emergency_wand_execute(context)
    if not context.target then return false end
    if NS.is_auto_attacking and NS.is_auto_attacking(context.me) then return true end
    return NS.start_auto_attack and NS.start_auto_attack(context.target, NS.AUTO_ATTACK_WAND) == true
end

-- ============================================================================
-- Strategies
-- ============================================================================
local strategies = {
    -- Out-of-combat Fortitude buff
    { name = "PowerWordFortitude", matches = fortitude_matches, execute = function(context, s) return NS.try_cast(ACTION.PowerWordFortitude, s.fortitude_target, "[SHADOW] PowerWordFortitude") end },
    { name = "PreCombatPull", matches = pre_combat_pull_matches, execute = function(context) return NS.try_cast(ACTION.VampiricTouch, context.target, "[SHADOW] PreCombatPull") end },
    { name = "Shadowform" }, -- DSL-substituted at runtime
    { name = "SWDCCBreak", matches = swd_cc_break_matches, execute = swd_cc_break_execute },
    { name = "Shadowfiend", matches = shadowfiend_matches, execute = function(context) return NS.try_cast(ACTION.Shadowfiend, context.target, "[SHADOW] Shadowfiend") end },
    { name = "VampiricTouch" }, -- DSL-substituted at runtime
    { name = "ShadowWordPain" }, -- DSL-substituted at runtime
    { name = "MovingSWP", matches = function(context, s)
        if not s.swp_known then return false end
        if not context.is_moving then return false end
        if not context.has_valid_enemy_target then return false end
        if NS.broken_api_throttled and NS.broken_api_throttled(ACTION.ShadowWordPain, 2.0) then return false end
        if (s.swp_remaining or 0) > 3 then return false end
        if s.mana_emergency then return false end
        if (s.swp_remaining or 0) <= 0 and not _engaged_with_player(context) then return false end
        return true
    end, execute = function(context) local ok = NS.try_cast(ACTION.ShadowWordPain, context.target, "[SHADOW] SWP (moving)"); if ok then shadow_state.snapshot_swp_dmg = shadow_state.spell_damage end; return ok end },
    { name = "VampiricEmbrace", matches = vampiric_embrace_matches, execute = function(context) return NS.try_cast(ACTION.VampiricEmbrace, context.target, "[SHADOW] VampiricEmbrace") end },
    { name = "DevouringPlague", matches = devouring_plague_matches, execute = function(context) local ok = NS.try_cast(ACTION.DevouringPlague, context.target, "[SHADOW] DevouringPlague"); if ok then shadow_state.snapshot_dp_dmg = shadow_state.spell_damage end; return ok end },
    { name = "InnerFocusMindBlast", matches = inner_focus_matches, execute = function(context) return NS.try_cast(ACTION.InnerFocus, NS.PLAYER_UNIT, "[SHADOW] InnerFocusâ†’MB Combo", { skip_range = true }) end },
    { name = "MindBlast" }, -- DSL-substituted at runtime
    { name = "Starshards", matches = starshards_matches, execute = function(context) return NS.try_cast(ACTION.Starshards, context.target, "[SHADOW] Starshards") end },
    { name = "ShadowWordDeath" }, -- DSL-substituted at runtime
    { name = "MindFlay", matches = mind_flay_matches, execute = function(context) return NS.try_cast(ACTION.MindFlay, context.target, "[SHADOW] MindFlay") end },
    { name = "PsychicScream", matches = psychic_scream_matches, execute = function(context) return NS.try_cast(ACTION.PsychicScream, context.target, "[SHADOW] PsychicScream") end },
    { name = "Fade",
      matches = function(context, state)
          local auto_fade = spec_kit.setting_bool(context, "priest_auto_fade", true)
          if not auto_fade then return false end
          if not context.in_combat then return false end
          if state.has_fade_buff then return false end
          if not state.fade_ready then return false end
          local threshold = spec_kit.setting_number(context, "priest_fade_threat_threshold", 80)
          if context.threat_pct and context.threat_pct >= threshold then return true end
          if context.threat_status and context.threat_status >= 2 then return true end
          return false
      end,
      execute = function(context) return NS.try_cast(ACTION.Fade, NS.PLAYER_UNIT, "[SHADOW] Fade", { skip_range = true }) end,
    },
    { name = "Healthstone",
      matches = function(context, state)
          local auto_hs = spec_kit.setting_bool(context, "auto_healthstone", true)
          if not auto_hs then return false end
          local threshold = spec_kit.setting_number(context, "healthstone_hp_threshold", 30)
          if (context.hp or 100) > threshold then return false end
          if context.is_casting then return false end
          return state and state.healthstone_ready == true
      end,
      execute = function(_, state)
          return state and state.healthstone_id and NS.use_item_by_id and NS.use_item_by_id(state.healthstone_id) or false
      end,
    },
    { name = "DispelMagic", matches = dispel_magic_matches, execute = function(context) return NS.try_cast(ACTION.DispelMagic, NS.PLAYER_UNIT, "[SHADOW] DispelMagic", { skip_range = true }) end },
    { name = "ShackleUndead", matches = shackle_undead_matches, execute = function(context) return NS.try_cast(ACTION.ShackleUndead, context.target, "[SHADOW] ShackleUndead") end },
    { name = "SWPSpread", matches = shadow_swp_spread_matches, execute = function(context)
        local target = context._shadow_swp_spread_target
        if not target then return false end
        _set_lockout("SWP", 3000, target)
        local ok = NS.try_cast(ACTION.ShadowWordPain, target, "[SHADOW] SWPSpread")
        if ok then shadow_state.snapshot_swp_dmg = shadow_state.spell_damage end
        context._shadow_swp_spread_target = nil
        return ok
    end },
    { name = "VTSpread", matches = shadow_vt_spread_matches, execute = function(context)
        local target = context._shadow_vt_spread_target
        if not target then return false end
        _set_lockout("VT", 3000, target)
        local ok = NS.try_cast(ACTION.VampiricTouch, target, "[SHADOW] VTSpread")
        if ok then shadow_state.snapshot_vt_dmg = shadow_state.spell_damage end
        context._shadow_vt_spread_target = nil
        return ok
    end },
    { name = "MultiDotSWP", matches = multidot_swp_matches, execute = function(context)
        local target = context._shadow_swp_spread_target
        if not target then return false end
        _set_lockout("SWP", 3000, target)
        local ok = NS.try_cast(ACTION.ShadowWordPain, target, "[SHADOW] MultiDoT SW:P")
        if ok then shadow_state.snapshot_swp_dmg = shadow_state.spell_damage end
        context._shadow_swp_spread_target = nil
        return ok
    end },
    { name = "MultiDotVT", matches = multidot_vt_matches, execute = function(context)
        local target = context._shadow_vt_spread_target
        if not target then return false end
        _set_lockout("VT", 3000, target)
        local ok = NS.try_cast(ACTION.VampiricTouch, target, "[SHADOW] MultiDoT VT")
        if ok then shadow_state.snapshot_vt_dmg = shadow_state.spell_damage end
        context._shadow_vt_spread_target = nil
        return ok
    end },
    { name = "InnerFire" }, -- DSL-substituted at runtime
    { name = "PowerWordShield", matches = power_word_shield_matches, execute = function(context) return NS.try_cast(ACTION.PowerWordShield, NS.PLAYER_UNIT, "[SHADOW] PowerWordShield", { skip_range = true }) end },
    { name = "FlashHeal", matches = flash_heal_matches, execute = function(context) return NS.try_cast(ACTION.FlashHeal, NS.PLAYER_UNIT, "[SHADOW] FlashHeal", { skip_range = true }) end },
    { name = "HolyNovaAoE", matches = holy_nova_aoe_matches, execute = function(context) return NS.try_cast(ACTION.HolyNova, context.target, "[SHADOW] HolyNova") end },
    -- Emergency wand fallback when mana below conserve floor (last resort)
    { name = "ManaEmergencyWand", matches = mana_emergency_wand_matches, execute = mana_emergency_wand_execute },
    { name = "RacialBerserking", matches = racial_matches, execute = function(context) return NS.try_cast(ACTION.Berserking, NS.PLAYER_UNIT, "[SHADOW] Berserking", { skip_range = true }) end },
    { name = "RacialBloodFury", matches = racial_matches, execute = function(context) return NS.try_cast(ACTION.BloodFury, NS.PLAYER_UNIT, "[SHADOW] BloodFury", { skip_range = true }) end },
    { name = "RacialArcaneTorrent", matches = racial_matches, execute = function(context) return NS.try_cast(ACTION.ArcaneTorrent, NS.PLAYER_UNIT, "[SHADOW] ArcaneTorrent", { skip_range = true }) end },
}

-- ============================================================================
-- Strategy DSL definitions (8th DSL adopter — first shadow priest/DoT-tracking spec)
-- Converts 6 strategies to declarative DSL, preserving priority order via
-- in-place substitution. Exercises: DoT tracking (VT, SW:P), execute range
-- (SW:D), shadow form management (Shadowform), cooldown/resource gating
-- (MindBlast mana/threat), OOC buffing (InnerFire), and the first use of
-- `context` condition type for is_casting/is_moving checks.
-- Resource model: mana-based DoT/caster.
-- ============================================================================
local DSL_DEFS = {
    -- Shadowform: apply shadow form if not already active and spell is known.
    -- Conditions: not broken_api throttled, no shadowform buff, spell known.
    {
        name = "Shadowform",
        conditions = {
            { type = "custom", fn = function(context, state)
                if NS.broken_api_throttled and NS.broken_api_throttled(ACTION.Shadowform, 3.0) then return false end
                return true
            end },
            { type = "state", field = "has_shadowform", op = "falsy" },
            { type = "state", field = "shadowform_known", op = "truthy" },
        },
        execute = function(context)
            return NS.try_cast(ACTION.Shadowform, NS.PLAYER_UNIT, "[SHADOW] Shadowform", { skip_range = true })
        end,
    },
    -- VampiricTouch: primary DoT application/refresh with snapshot awareness.
    -- Conditions: spell known, not casting/channeling, not broken_api, can break MF, not moving,
    --              valid target, VT remaining <= clip threshold, TTD gate, DoT TTD gating,
    --              not mana emergency, snapshot upgrade check, engaged with player.
    {
        name = "VampiricTouch",
        conditions = {
            { type = "state", field = "vampiric_touch_known", op = "truthy" },
            { type = "context", field = "is_casting", op = "falsy" },
            { type = "context", field = "is_channeling", op = "falsy" },
            { type = "custom", fn = function(context, state)
                if NS.broken_api_throttled and NS.broken_api_throttled(ACTION.VampiricTouch, 2.0) then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                return can_break_mind_flay(state)
            end },
            { type = "context", field = "is_moving", op = "falsy" },
            { type = "context", field = "has_valid_enemy_target", op = "truthy" },
            { type = "custom", fn = function(context, state)
                if (state.vt_remaining or 0) > vt_clip_threshold(context) then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                if context.ttd_known and context.ttd > 0 and context.ttd < 6 then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                local ttd_threshold = spec_kit.setting_number(context, "shadow_dot_ttd_threshold", 50) / 100
                if DotTTD.should_skip_dot(context.ttd, DotTTD.DOT_DURATIONS.vampiric_touch, ttd_threshold) then return false end
                return true
            end },
            { type = "state", field = "mana_emergency", op = "falsy" },
            { type = "custom", fn = function(context, state)
                local ratio = state.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
                if state.vt_remaining > 0 and not should_snapshot_upgrade(state.spell_damage, state.snapshot_vt_dmg, state.vt_remaining, 3, ratio) then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                if (state.vt_remaining or 0) <= 0 and not _engaged_with_player(context) then return false end
                return true
            end },
        },
        execute = function(context)
            local ok = NS.try_cast(ACTION.VampiricTouch, context.target, "[SHADOW] VampiricTouch")
            if ok then shadow_state.snapshot_vt_dmg = shadow_state.spell_damage end
            return ok
        end,
    },
    -- ShadowWordPain: DoT application/refresh with shadow weaving and snapshot awareness.
    -- Conditions: spell known, not broken_api, can break MF, valid target, not mana emergency,
    --              weaving-aware refresh window, snapshot upgrade, TTD gate.
    {
        name = "ShadowWordPain",
        conditions = {
            { type = "state", field = "swp_known", op = "truthy" },
            { type = "custom", fn = function(context, state)
                if NS.broken_api_throttled and NS.broken_api_throttled(ACTION.ShadowWordPain, 2.0) then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                return can_break_mind_flay(state)
            end },
            { type = "context", field = "has_valid_enemy_target", op = "truthy" },
            { type = "state", field = "mana_emergency", op = "falsy" },
            { type = "custom", fn = function(context, state)
                if (state.swp_remaining or 0) <= 0 and not _engaged_with_player(context) then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                local sw_window = swp_clip_threshold(context)
                local effective_window = (state.weaving_stacks > 0 and state.weaving_stacks < 5) and 5 or sw_window
                if state.swp_remaining > effective_window then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                local ratio = state.has_bloodlust and BLOODLUST_LOWER_RATIO or SPELL_DMG_UPGRADE_RATIO
                if state.swp_remaining > 0 and not should_snapshot_upgrade(state.spell_damage, state.snapshot_swp_dmg, state.swp_remaining, swp_clip_threshold(context), ratio) then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                local ttd_threshold = spec_kit.setting_number(context, "shadow_dot_ttd_threshold", 50) / 100
                if DotTTD.should_skip_dot(context.ttd, DotTTD.DOT_DURATIONS.shadow_word_pain, ttd_threshold) then return false end
                return true
            end },
        },
        execute = function(context)
            local ok = NS.try_cast(ACTION.ShadowWordPain, context.target, "[SHADOW] ShadowWordPain")
            if ok then shadow_state.snapshot_swp_dmg = shadow_state.spell_damage end
            return ok
        end,
    },
    -- MindBlast: primary nuke with mana/threat/engagement gating.
    -- Conditions: not casting/channeling, can break MF, not moving, valid target,
    --              spell ready, not mana low, threat safe, engaged with player.
    {
        name = "MindBlast",
        conditions = {
            { type = "context", field = "is_casting", op = "falsy" },
            { type = "context", field = "is_channeling", op = "falsy" },
            { type = "custom", fn = function(context, state)
                return can_break_mind_flay(state)
            end },
            { type = "context", field = "is_moving", op = "falsy" },
            { type = "context", field = "has_valid_enemy_target", op = "truthy" },
            { type = "state", field = "mb_ready", op = "truthy" },
            { type = "state", field = "mana_low", op = "falsy" },
            { type = "state", field = "threat_safe", op = "truthy" },
            { type = "custom", fn = function(context, state)
                return _engaged_with_player(context)
            end },
        },
        execute = function(context)
            return NS.try_cast(ACTION.MindBlast, context.target, "[SHADOW] MindBlast")
        end,
    },
    -- ShadowWordDeath: execute-range nuke with safety and threat gating.
    -- Conditions: can break MF, valid target, spell ready, TTD gate, not mana emergency,
    --              threat safe, execute/safety HP check, engaged with player.
    {
        name = "ShadowWordDeath",
        conditions = {
            { type = "custom", fn = function(context, state)
                return can_break_mind_flay(state)
            end },
            { type = "context", field = "has_valid_enemy_target", op = "truthy" },
            { type = "state", field = "swd_ready", op = "truthy" },
            { type = "custom", fn = function(context, state)
                if context.ttd_known and context.ttd > 0 and context.ttd < 3 then return false end
                return true
            end },
            { type = "state", field = "mana_emergency", op = "falsy" },
            { type = "state", field = "threat_safe", op = "truthy" },
            { type = "custom", fn = function(context, state)
                local target_hp = (context.target_hp_pct or context.target_hp or 100)
                local in_execute = target_hp <= 25
                local safety_floor = in_execute and 60 or (state.swd_safety_hp or 80)
                if (context.hp or 100) < safety_floor then return false end
                return true
            end },
            { type = "custom", fn = function(context, state)
                return _engaged_with_player(context)
            end },
        },
        execute = function(context)
            return NS.try_cast(ACTION.ShadowWordDeath, context.target, "[SHADOW] ShadowWordDeath")
        end,
    },
    -- InnerFire: OOC self-buff with broken_api throttle and setting gate.
    -- Conditions: spell known, not broken_api, no inner fire buff, setting enabled, not in combat.
    {
        name = "InnerFire",
        conditions = {
            { type = "state", field = "inner_fire_known", op = "truthy" },
            { type = "custom", fn = function(context, state)
                if NS.broken_api_throttled and NS.broken_api_throttled(ACTION.InnerFire, 3.0) then return false end
                return true
            end },
            { type = "state", field = "has_inner_fire", op = "falsy" },
            { type = "setting", key = "shadow_use_inner_fire", default = true },
            { type = "context", field = "in_combat", op = "falsy" },
        },
        execute = function(context)
            return NS.try_cast(ACTION.InnerFire, NS.PLAYER_UNIT, "[SHADOW] InnerFire", { skip_range = true })
        end,
    },
}

-- In-place substitution: replace matching strategy entries with DSL-compiled versions,
-- preserving priority order. Named match functions remain as dead code (cleaned up later).
local DSL_STRATEGIES = dsl.compile_strategies(DSL_DEFS, { get_state = build_state })
local _dsl_by_name = {}
for _i = 1, #DSL_STRATEGIES do _dsl_by_name[DSL_STRATEGIES[_i].name] = DSL_STRATEGIES[_i] end
for _i = 1, #strategies do
    local _dsl = _dsl_by_name[strategies[_i].name]
    if _dsl then
        strategies[_i] = _dsl
    end
end

if NS.rotation_registry and NS.rotation_registry.register then
    NS.rotation_registry:register("shadow", strategies, { get_state = build_state })
end
-- Priest shadow rotation registered

return { strategies = strategies, build_state = build_state }

