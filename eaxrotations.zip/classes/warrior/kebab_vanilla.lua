-- kebab_vanilla.lua — Warrior "Kebab" (1H Fury/DW Arms) for Vanilla/Classic Anniversary (1.15.x).
-- WHAT:  dual-wield 1H hybrid (same rotation as Fury DW).
-- WHEN:  combat, when NS.is_vanilla() is true.
-- WHY:   meme/community spec; uses Fury rotation with 1H weapons.
-- SAFETY: nil-guards on NS, SPELLS, and state fields per Pattern 14.

local NS = _G.EaxRotations
if not NS then return nil end

local potion_helper = require("shared/potion_helper_sylvanas")

local load_player = NS.GetPlayer and NS.GetPlayer()

local _ok_enums, enums = pcall(require, "common/enums")
if not _ok_enums or type(enums) ~= "table" or type(enums.class_id) ~= "table" then enums = { class_id = NS.CLASS_ID } end
local ok_cls, cls_id = pcall(function() return load_player:get_class() end)
if not ok_cls or cls_id ~= enums.class_id.WARRIOR then return end

local SPELLS = NS.WarriorSpells
local Constants = NS.WarriorConstants
local format = string.format
local EMPTY_SETTINGS = {}

local function settings_for(context)
    return (context and context.settings) or EMPTY_SETTINGS
end

local function safe_unit_call(unit, method, ...)
    if not unit or type(unit[method]) ~= "function" then return nil end
    local ok, value = pcall(unit[method], unit, ...)
    if ok then return value end
    return nil
end

local SUNDER_DEBUFF = { 7386, 7405, 8380, 11596, 11597 }
local THUNDER_CLAP_DEBUFF = { 6343, 8198, 8204, 8205, 11580, 11581 }
local DEMO_SHOUT_DEBUFF = { 11556, 11555, 11554, 6190, 1160 }
local BATTLE_SHOUT_IDS = Constants.BATTLE_SHOUT_IDS or { 11551, 11550, 11549, 6192, 5242, 6673 }

local try_cast, spell_exists, spell_ready, debuff_remains, debuff_stacks, buff_remains, health_pct, player_control_locked, has_player_buff, has_breakable_cc_nearby, can_attack_target = NS.import_helpers(
    "try_cast", "spell_exists", "spell_ready", "debuff_remains",
    "debuff_stacks", "buff_remains", "health_pct", "player_control_locked", "has_player_buff", "has_breakable_cc_nearby", "can_attack_target"
)
local is_execute_phase = NS.is_execute_phase or function(hp, threshold) return (hp or 100) <= (threshold or 20) end

local get_debuff_stacks = debuff_stacks
local get_debuff_remains = debuff_remains

local function battle_shout_needs_refresh(unit)
    if not unit then return true end
    local min_refresh = 30
    for _, id in ipairs(BATTLE_SHOUT_IDS) do
        local remains = NS.buff_remains(unit, {id}) or 0
        if remains > min_refresh then return false end
    end
    return true
end

local OFFHAND_SLOT = 17
local function has_offhand_weapon()
    if NS.get_equipped_item_id and NS.get_equipped_item_id(OFFHAND_SLOT) then
        return true
    end
    local player = NS.GetPlayer()
    if not player or not player.get_item_at_inventory_slot then return false end
    local slot_info = safe_unit_call(player, "get_item_at_inventory_slot", OFFHAND_SLOT)
    return slot_info ~= nil and slot_info.entry ~= nil and slot_info.entry ~= 0
end

local function get_cooldown(spell)
    return NS.cooldown_remains and NS.cooldown_remains(spell) or 0
end

local function is_spell_current(spell_id)
    return NS.is_current_spell(spell_id)
end

local HEROIC_STRIKE_ID = NS.get_spell_id(SPELLS.HeroicStrike) or 78
local CLEAVE_ID = NS.get_spell_id(SPELLS.Cleave) or 845

local RAGE_COST_MS = 30
local RAGE_COST_WW = 25
local RAGE_COST_PUMMEL = 10

local SS_RESERVE_FLOOR = 60
local SS_POOL_WINDOW = 2.0

local function should_reserve_for_sweeping(context)
    local settings = settings_for(context)
    if (context.enemy_count or 0) < 2 then return false end
    if settings.kebab_use_sweeping_strikes == false then return false end
    if not spell_exists(SPELLS.SweepingStrikes) then return false end
    if has_player_buff(Constants.BUFF_ID.SWEEPING_STRIKES or 12292) then return false end
    local ss_cd = get_cooldown(SPELLS.SweepingStrikes)
    if ss_cd > SS_POOL_WINDOW then return false end
    if ss_cd <= SS_POOL_WINDOW and (context.rage or 0) < SS_RESERVE_FLOOR then return true end
    return false
end

local function would_starve_core_kebab(context, state, cost)
    cost = cost or 15
    local settings = settings_for(context)
    if (state.ms_cd or 99) >= 0 and (state.ms_cd or 99) <= 1.5 and context.in_melee_range then
        if ((context.rage or 0) - cost) < RAGE_COST_MS then return true end
    end
    if settings.kebab_use_whirlwind ~= false then
        if (state.ww_cd or 99) >= 0 and (state.ww_cd or 99) <= 1.5 and context.in_melee_range then
            if ((context.rage or 0) - cost) < RAGE_COST_WW then return true end
        end
    end
    return false
end

local kebab_state = {
    general_use = false,
    target_below_20 = false,
    sunder_stacks = 0,
    sunder_duration = 0,
    thunder_clap_duration = 0,
    demo_shout_duration = 0,
    ms_cd = 0,
    ww_cd = 0,
}

local function build_kebab_state(context)
    if context._kebab_valid then return kebab_state end
    context._kebab_valid = true
    context.settings = context.settings or EMPTY_SETTINGS

    local target = context.target

    context.enemy_count = context.enemies_count or 0
    context.target_hp = target and health_pct(target) or 100
    context.in_melee_range = target and safe_unit_call(target, "is_in_melee_range", 5) or false
    context.has_breakable_cc_nearby = has_breakable_cc_nearby(context)
    context.player_control_locked = (type(player_control_locked) == "function" and player_control_locked()) or false
    local player = NS.GetPlayer()
    context.is_moving = safe_unit_call(player, "is_moving") or false
    context.has_offhand = has_offhand_weapon()
    local settings = settings_for(context)
    kebab_state.general_use = settings.kebab_general_use == true
        or context.is_leveling == true
        or (context.player_level and context.player_level < 62)
        or not context.has_offhand

    context.mh_remain = NS.get_time_until_swing and NS.get_time_until_swing() or nil
    context.oh_remain = NS.get_time_until_oh_swing and NS.get_time_until_oh_swing() or nil

    kebab_state.target_below_20 = is_execute_phase(context.target_hp, 20)
    kebab_state.sunder_stacks = target and get_debuff_stacks(target, SUNDER_DEBUFF) or 0
    kebab_state.sunder_duration = target and get_debuff_remains(target, SUNDER_DEBUFF) or 0
    kebab_state.thunder_clap_duration = target and get_debuff_remains(target, THUNDER_CLAP_DEBUFF) or 0
    kebab_state.demo_shout_duration = target and get_debuff_remains(target, DEMO_SHOUT_DEBUFF) or 0
    kebab_state.ms_cd = get_cooldown(SPELLS.MortalStrike)
    kebab_state.ww_cd = get_cooldown(SPELLS.Whirlwind)

    return kebab_state
end

local function general_use_kebab(context, state)
    if settings_for(context).kebab_force_dw_priority == true then return false end
    return state and state.general_use == true
end

local strategies = {
    {
        name = "HealthPotion",
        matches = function(context)
            if not context.in_combat then return false end
            if context.settings and context.settings.use_auto_potions == false then return false end
            if not context.has_health_potion then return false end
            if (context.hp or 100) > 35 then return false end
            return true
        end,
        execute = function(context) return potion_helper.try_use_potion(context, potion_helper.HEALTH_POTION_IDS) end,
    },
    {
        name = "DamagePotion",
        matches = function(context)
            if not context.in_combat then return false end
            if context.settings and context.settings.use_auto_potions == false then return false end
            if not context.has_damage_potion then return false end
            if not context.should_burst then return false end
            return true
        end,
        execute = function(context) return potion_helper.try_use_potion(context, potion_helper.DAMAGE_POTION_IDS) end,
    },
    {
        name = "Execute",
        matches = function(context, state)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if settings.kebab_execute_phase == false then return false end
            if not state.target_below_20 then return false end
            if (context.rage or 0) < 15 then return false end
            if not general_use_kebab(context, state) then
                if settings.kebab_use_ww_execute ~= false and (context.rage or 0) >= 25 and (state.ww_cd or 0) <= 0 then return false end
                if settings.kebab_use_ms_execute ~= false and (context.rage or 0) >= 30 and (state.ms_cd or 0) <= 0 then return false end
            end
            if context.stance ~= Constants.STANCE.BATTLE and context.stance ~= Constants.STANCE.BERSERKER then
                return spell_exists(SPELLS.BerserkerStance) and spell_ready(SPELLS.BerserkerStance, NS.PLAYER_UNIT)
            end
            return spell_exists(SPELLS.Execute) and spell_ready(SPELLS.Execute, context.target)
        end,
        execute = function(context, state)
            if context.stance ~= Constants.STANCE.BATTLE and context.stance ~= Constants.STANCE.BERSERKER then
                return try_cast(SPELLS.BerserkerStance, NS.PLAYER_UNIT, "[KEBAB] Berserker Stance (for Execute)", { skip_range = true })
            end
            return try_cast(SPELLS.Execute, context.target,
                format("[KEBAB] Execute - Rage: %d, HP: %.0f%%", context.rage or 0, context.target_hp or 0))
        end,
    },
    {
        name = "SweepingStrikes",
        matches = function(context)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if settings.kebab_use_sweeping_strikes == false then return false end
            if (context.enemy_count or 0) < 2 then return false end
            if has_player_buff(Constants.BUFF_ID.SWEEPING_STRIKES or 12292) then return false end
            if (context.rage or 0) < 30 then return false end
            if context.stance ~= Constants.STANCE.BATTLE then
                return spell_exists(SPELLS.BattleStance) and spell_ready(SPELLS.BattleStance, NS.PLAYER_UNIT)
            end
            return spell_exists(SPELLS.SweepingStrikes) and spell_ready(SPELLS.SweepingStrikes, NS.PLAYER_UNIT)
        end,
        execute = function(context)
            if context.stance ~= Constants.STANCE.BATTLE then
                return try_cast(SPELLS.BattleStance, NS.PLAYER_UNIT, "[KEBAB] Battle Stance (for Sweeping Strikes)", { skip_range = true })
            end
            return try_cast(SPELLS.SweepingStrikes, NS.PLAYER_UNIT,
                format("[KEBAB] Sweeping Strikes - Rage: %d, Enemies: %d", context.rage or 0, context.enemy_count or 0), { skip_range = true })
        end,
    },
    {
        name = "MortalStrikeGeneralUse",
        matches = function(context, state)
            local settings = settings_for(context)
            if not general_use_kebab(context, state) then return false end
            if not can_attack_target(context) then return false end
            if state.target_below_20 and settings.kebab_execute_phase and settings.kebab_use_ms_execute == false then return false end
            if (context.rage or 0) < 30 then return false end
            return spell_exists(SPELLS.MortalStrike) and spell_ready(SPELLS.MortalStrike, context.target)
        end,
        execute = function(context)
            return try_cast(SPELLS.MortalStrike, context.target, "[KEBAB] Mortal Strike general-use")
        end,
    },
    {
        name = "Whirlwind",
        matches = function(context, state)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if settings.kebab_use_whirlwind == false then return false end
            if general_use_kebab(context, state) and (context.enemy_count or 0) < 2 then return false end
            if context.has_breakable_cc_nearby and settings.pvp_cc_break_check then return false end
            if state.target_below_20 and settings.kebab_execute_phase then
                if not settings.kebab_use_ww_execute then return false end
            end
            if (context.rage or 0) < 25 then return false end
            if should_reserve_for_sweeping(context) then return false end
            if context.stance ~= Constants.STANCE.BERSERKER then
                return spell_exists(SPELLS.BerserkerStance) and spell_ready(SPELLS.BerserkerStance, NS.PLAYER_UNIT)
            end
            return spell_exists(SPELLS.Whirlwind) and spell_ready(SPELLS.Whirlwind, NS.PLAYER_UNIT)
        end,
        execute = function(context)
            if context.stance ~= Constants.STANCE.BERSERKER then
                return try_cast(SPELLS.BerserkerStance, NS.PLAYER_UNIT, "[KEBAB] Berserker Stance (for WW)", { skip_range = true })
            end
            return try_cast(SPELLS.Whirlwind, NS.PLAYER_UNIT,
                format("[KEBAB] Whirlwind - Rage: %d", context.rage or 0), { skip_range = true })
        end,
    },
    {
        name = "MortalStrike",
        matches = function(context, state)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if state.target_below_20 and settings.kebab_execute_phase then
                if not settings.kebab_use_ms_execute then return false end
            end
            return spell_exists(SPELLS.MortalStrike) and spell_ready(SPELLS.MortalStrike, context.target)
        end,
        execute = function(context)
            return try_cast(SPELLS.MortalStrike, context.target, "[KEBAB] Mortal Strike")
        end,
    },
    {
        name = "Overpower",
        matches = function(context)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if settings.kebab_use_overpower == false then return false end
            if context.stance ~= Constants.STANCE.BATTLE then return false end
            return spell_exists(SPELLS.Overpower) and spell_ready(SPELLS.Overpower, context.target)
        end,
        execute = function(context)
            return try_cast(SPELLS.Overpower, context.target,
                format("[KEBAB] Overpower - Rage: %d", context.rage or 0))
        end,
    },
    {
        name = "BattleShout",
        is_gcd_gated = false,
        matches = function(context)
            local settings = settings_for(context)
            if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.BattleShout, 3.0) then return false end
            if settings.auto_shout == false then return false end
            local shout_type = settings.shout_type or "battle"
            if shout_type ~= "battle" then return false end
            if not can_attack_target(context) then return false end
            if context.has_breakable_cc_nearby and settings.pvp_cc_break_check then return false end
            local player = NS.GetPlayer()
            if not battle_shout_needs_refresh(player) then return false end
            if (context.rage or 0) < 10 then return false end
            return spell_exists(SPELLS.BattleShout) and spell_ready(SPELLS.BattleShout, NS.PLAYER_UNIT)
        end,
        execute = function()
            return try_cast(SPELLS.BattleShout, NS.PLAYER_UNIT, "[KEBAB] Battle Shout", { skip_range = true })
        end,
    },
    {
        name = "SunderMaintain",
        matches = function(context, state)
            local settings = settings_for(context)
            if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.SunderArmor, 2.0) then return false end
            local mode = settings.sunder_armor_mode or "none"
            if not can_attack_target(context) or mode == "none" then return false end
            -- Skip if target has no armor (API unavailable or already fully reduced)
            if (context.target_armor or 0) <= 0 then return false end
            if context.stance ~= Constants.STANCE.BATTLE and context.stance ~= Constants.STANCE.DEFENSIVE then return false end

            if mode == "help_stack" then
                if (state.sunder_stacks or 0) >= (Constants.SUNDER_MAX_STACKS or 5) then return false end
            elseif mode == "maintain" then
                if (state.sunder_stacks or 0) >= (Constants.SUNDER_MAX_STACKS or 5)
                    and (state.sunder_duration or 0) > (Constants.SUNDER_REFRESH_WINDOW or 3)
                then
                    return false
                end
            end

            return spell_exists(SPELLS.SunderArmor) and spell_ready(SPELLS.SunderArmor, context.target)
        end,
        execute = function(context, state)
            return try_cast(SPELLS.SunderArmor, context.target,
                format("[KEBAB] Sunder Armor - Stacks: %d", state.sunder_stacks or 0))
        end,
    },
    {
        name = "ThunderClap",
        matches = function(context, state)
            local settings = settings_for(context)
            if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.ThunderClap, 2.0) then return false end
            if not can_attack_target(context) then return false end
            if settings.maintain_thunder_clap == false then return false end
            if context.has_breakable_cc_nearby and settings.pvp_cc_break_check then return false end
            if (state.thunder_clap_duration or 0) > (Constants.TC_REFRESH_WINDOW or 2) then return false end
            if context.stance ~= Constants.STANCE.BATTLE then return false end
            return spell_exists(SPELLS.ThunderClap) and spell_ready(SPELLS.ThunderClap, NS.PLAYER_UNIT)
        end,
        execute = function()
            return try_cast(SPELLS.ThunderClap, NS.PLAYER_UNIT,
                format("[KEBAB] Thunder Clap - Duration: %.1fs", kebab_state.thunder_clap_duration or 0), { skip_range = true })
        end,
    },
    {
        name = "DemoShout",
        matches = function(context, state)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if settings.maintain_demo_shout == false then return false end
            if context.has_breakable_cc_nearby and settings.pvp_cc_break_check then return false end
            if not context.in_melee_range then return false end
            if (state.demo_shout_duration or 0) > 3 then return false end
            return spell_exists(SPELLS.DemoralizingShout) and spell_ready(SPELLS.DemoralizingShout, NS.PLAYER_UNIT)
        end,
        execute = function()
            return try_cast(SPELLS.DemoralizingShout, NS.PLAYER_UNIT,
                format("[KEBAB] Demo Shout - Duration: %.1fs", kebab_state.demo_shout_duration or 0), { skip_range = true })
        end,
    },
    {
        name = "HeroicStrike",
        is_gcd_gated = false,
        matches = function(context, state)
            local settings = settings_for(context)
            if not can_attack_target(context) then return false end
            if is_spell_current(HEROIC_STRIKE_ID) or is_spell_current(CLEAVE_ID) then return false end
            if state.target_below_20 and settings.kebab_execute_phase then
                if not settings.kebab_hs_during_execute then return false end
            end

            if settings.hs_trick and context.has_offhand then
                local oh_remaining = context.oh_remain
                local mh_remaining = context.mh_remain
                if oh_remaining and mh_remaining and oh_remaining > 0 and oh_remaining <= 0.4 then
                    if mh_remaining > oh_remaining + 0.3 then
                        return true
                    end
                end
            end

            local threshold = settings.kebab_hs_rage_threshold or 40
            if settings.hs_trick and context.has_offhand then
                threshold = 30
            end
            if general_use_kebab(context, state) and threshold < 55 then
                threshold = 55
            end
            if (context.rage or 0) < threshold then return false end

            if would_starve_core_kebab(context, state, 15) then return false end

            if settings.use_interrupt then
                local should_kick = NS.try_interrupt(context.target)
                if should_kick then
                    if ((context.rage or 0) - 15) < RAGE_COST_PUMMEL then return false end
                end
            end

            return true
        end,
        execute = function(context)
            local settings = settings_for(context)
            local cleave_at = settings.aoe_threshold or 2
            local cc_safe = not (context.has_breakable_cc_nearby and settings.pvp_cc_break_check)
            if cc_safe and cleave_at > 0 and (context.enemy_count or 0) >= cleave_at
                and spell_exists(SPELLS.Cleave) and spell_ready(SPELLS.Cleave, context.target)
            then
                return try_cast(SPELLS.Cleave, context.target,
                    format("[KEBAB] Cleave - Rage: %d, Enemies: %d", context.rage or 0, context.enemy_count or 0))
            end

            if spell_exists(SPELLS.HeroicStrike) and spell_ready(SPELLS.HeroicStrike, context.target) then
                return try_cast(SPELLS.HeroicStrike, context.target,
                    format("[KEBAB] Heroic Strike - Rage: %d", context.rage or 0))
            end
            return false
        end,
    },
}

NS.rotation_registry:register("kebab", strategies, {
    context_builder = build_kebab_state,
})

-- Kebab_vanilla (DW Arms) rotation registered (Classic Vanilla)
return strategies
