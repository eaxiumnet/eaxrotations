-- protection_vanilla.lua — Warrior Protection tank for Vanilla/Classic Anniversary (1.15.x).
-- WHAT:  tank (Sunder Armor, Shield Slam, Revenge, Shield Block).
-- WHEN:  combat, when NS.is_vanilla() is true.
-- WHY:   expansion-aware loader selects _vanilla suffix for Classic Era.
-- SAFETY: nil-guards on NS, SPELLS, and state fields per Pattern 14.

local NS = _G.EaxRotations
if not NS then return nil end

-- Hit-volume AoE gates (install if core not loaded, e.g. unit tests)
do
    local _ok_aoe, AoeHV = pcall(require, "shared/aoe_hit_volume_sylvanas")
    if _ok_aoe and AoeHV and AoeHV.install then AoeHV.install(NS) end
end

local spec_kit = require("shared/spec_kit_sylvanas")
local SPELLS = NS.WarriorSpells or {}

local potion_helper = require("shared/potion_helper_sylvanas")
local CONSTANTS = NS.WarriorConstants or {}
local STANCE = CONSTANTS.STANCE or { BATTLE = 1, DEFENSIVE = 2, BERSERKER = 3 }

local SUNDER_WINDOW = 3
local SUNDER_MAX_STACKS = 5
local HEROIC_STRIKE_RAGE_DUMP = 70
local LOW_HP_LIMIT = 35
local THUNDERCLAP_CD = 4
local SHIELD_BLOCK_CD = 5
local SHIELD_SLAM_CD = 6
local REVENGE_CD = 5
local DEMO_SHOUT_CD = 25
local BLOODRAGE_CD = 60
local DISARM_CD = 60
local INTIMIDATING_SHOUT_CD = 180
local SHIELD_WALL_CD = 1800
local LAST_STAND_CD = 480

local TEST_ASSERTIONS = {
    { name = "DemoralizingShout", cooldown = DEMO_SHOUT_CD },
    { name = "ThunderClap", cooldown = THUNDERCLAP_CD },
}

local SUNDER_DEBUFF = CONSTANTS.SUNDER_DEBUFF or { 11597, 11596, 8380, 7405, 7386 }
local DEMO_SHOUT_DEBUFF = CONSTANTS.DEMO_SHOUT_DEBUFF or { 11556, 11555, 11554, 6190, 1160 }
local THUNDER_CLAP_DEBUFF = CONSTANTS.THUNDER_CLAP_DEBUFF or { 11581, 11580, 8205, 8204, 8198, 6343 }
local BATTLE_SHOUT_BUFF = CONSTANTS.BATTLE_SHOUT_IDS or { 11551, 11550, 11549, 6192, 5242, 6673 }
local STAND_BUFF = { 12975 }
local SHIELD_WALL_BUFF = { 871 }
local REND_DEBUFF = { 11574, 11573, 6548, 6547, 772 }
local SHIELD_BLOCK_BUFF = { 2565 }  -- Vanilla Shield Block buff ID (not the spell-action object)

local DISARM_CLASS_IDS = CONSTANTS.DISARM_CLASS_IDS or { [1] = true, [2] = true, [4] = true, [7] = true }

local function target_is_casting(unit)
    if not unit or type(unit.is_casting) ~= "function" then return false end
    local ok, casting = pcall(unit.is_casting, unit)
    return ok and casting == true
end

local prot_state = {
    sunder_stacks = 0,
    sunder_remains = 0,
    demo_remains = 0,
    tclap_remains = 0,
    hp = 100,
    rage = 0,
    stance = 2,
    enemy_count = 1,
    is_pvp = false,
    in_combat = false,
    target_hp = 100,
    target_is_casting = false,
    target_casting_interruptible = false,
    has_battle_shout = false,
    has_last_stand = false,
    has_shield_wall = false,
    revenge_ready = false,
    shield_slam_ready = false,
    shield_block_ready = false,
    demo_ready = false,
    tclap_ready = false,
    hs_ready = false,
    execute_ready = false,
    pummel_ready = false,
    taunt_ready = false,
    mocking_ready = false,
    challenging_ready = false,
    disarm_ready = false,
    intercept_ready = false,
    hamstring_ready = false,
    berserker_rage_ready = false,
    battle_shout_ready = false,
    shield_bash_ready = false,
    bloodrage_ready = false,
    rend_ready = false,
    intimidating_shout_ready = false,
    sunder_ready = false,
}

local setting = spec_kit.setting

local _last_build_state_time = -1
local function build_state(context)
    local state = prot_state
    local now = context.now
    if now and now == _last_build_state_time then return state end
    now = now or (NS.time_now and NS.time_now() or 0)
    if context.now then _last_build_state_time = now end
    state.now = now
    local target = context.target
    if target then
        prot_state.sunder_stacks = NS.get_debuff_stacks and NS.get_debuff_stacks(target, SUNDER_DEBUFF) or 0
        prot_state.sunder_remains = NS.debuff_remains and NS.debuff_remains(target, SUNDER_DEBUFF) or 0
        prot_state.demo_remains = NS.debuff_remains and NS.debuff_remains(target, DEMO_SHOUT_DEBUFF) or 0
        prot_state.tclap_remains = NS.debuff_remains and NS.debuff_remains(target, THUNDER_CLAP_DEBUFF) or 0
    else
        prot_state.sunder_stacks = 0
        prot_state.sunder_remains = 0
        prot_state.demo_remains = 0
        prot_state.tclap_remains = 0
    end
    prot_state.hp = context.hp or 100
    prot_state.rage = context.rage or 0
    prot_state.stance = context.stance or 2
    prot_state.enemy_count = context.enemy_count or 1
    prot_state.is_pvp = context.is_pvp or false
    prot_state.in_combat = context.in_combat or false
    prot_state.target_hp = context.target_hp or 100
    prot_state.target_is_casting = target_is_casting(target)
    prot_state.target_casting_interruptible = NS.is_interruptible and NS.is_interruptible(target) or false

    local me = context.me or NS.GetPlayer()
    prot_state.has_battle_shout = me and NS.buff_up(me, BATTLE_SHOUT_BUFF) or false
    prot_state.has_last_stand = me and NS.buff_up(me, STAND_BUFF) or false
    prot_state.has_shield_wall = me and NS.buff_up(me, SHIELD_WALL_BUFF) or false

    prot_state.revenge_ready = target and NS.spell_ready(SPELLS.Revenge, target, { expected_cooldown = REVENGE_CD }) or false
    prot_state.shield_slam_ready = target and NS.spell_ready(SPELLS.ShieldSlam, target, { expected_cooldown = SHIELD_SLAM_CD }) or false
    prot_state.shield_block_ready = me and NS.spell_ready(SPELLS.ShieldBlock, me, { skip_range = true, expected_cooldown = SHIELD_BLOCK_CD }) or false
    prot_state.demo_ready = me and NS.spell_ready(SPELLS.DemoralizingShout, me, { skip_range = true, expected_cooldown = DEMO_SHOUT_CD }) or false
    prot_state.tclap_ready = me and NS.spell_ready(SPELLS.ThunderClap, me, { skip_range = true, expected_cooldown = THUNDERCLAP_CD }) or false
    prot_state.hs_ready = target and NS.spell_ready(SPELLS.HeroicStrike, target) or false
    prot_state.execute_ready = target and NS.spell_ready(SPELLS.Execute, target) or false
    prot_state.pummel_ready = target and NS.spell_ready(SPELLS.Pummel, target) or false
    prot_state.taunt_ready = target and NS.spell_ready(SPELLS.Taunt, target) or false
    prot_state.mocking_ready = target and NS.spell_ready(SPELLS.MockingBlow, target) or false
    prot_state.challenging_ready = me and NS.spell_ready(SPELLS.ChallengingShout, me, { skip_range = true }) or false
    prot_state.disarm_ready = target and NS.spell_ready(SPELLS.Disarm, target) or false
    prot_state.intercept_ready = target and NS.spell_ready(SPELLS.Intercept, target) or false
    prot_state.hamstring_ready = target and NS.spell_ready(SPELLS.Hamstring, target) or false
    prot_state.berserker_rage_ready = me and NS.spell_ready(SPELLS.BerserkerRage, me, { skip_range = true }) or false
    prot_state.battle_shout_ready = me and NS.spell_ready(SPELLS.BattleShout, me, { skip_range = true }) or false
    prot_state.shield_bash_ready = target and NS.spell_ready(SPELLS.ShieldBash, target) or false
    prot_state.bloodrage_ready = me and NS.spell_ready(SPELLS.Bloodrage, me, { skip_range = true, expected_cooldown = BLOODRAGE_CD }) or false
    prot_state.rend_ready = target and NS.spell_ready(SPELLS.Rend, target) or false
    prot_state.intimidating_shout_ready = me and NS.spell_ready(SPELLS.IntimidatingShout, me, { skip_range = true, expected_cooldown = INTIMIDATING_SHOUT_CD }) or false
    prot_state.sunder_ready = target and NS.spell_ready(SPELLS.SunderArmor, target) or false

    return prot_state
end

local function is_defensive_stance(stance)
    return stance == STANCE.DEFENSIVE
end

local function sunder_matches_fn(context, state)
    if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.SunderArmor, 2.0) then return false end
    if not context.target then return false end
    -- Skip if target has no armor (armorless mob or API unavailable)
    if (context.target_armor or 0) <= 0 then return false end
    if (state.sunder_stacks or 0) < SUNDER_MAX_STACKS then
        return state.revenge_ready == false
    end
    if (state.sunder_remains or 0) <= SUNDER_WINDOW then
        return state.revenge_ready == false
    end
    return false
end

local function thunderclap_matches_fn(context, state)
    if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.ThunderClap, 2.0) then return false end
    if state.stance ~= STANCE.BATTLE then return false end  -- Vanilla TC requires Battle Stance
    -- Thunder Clap: 8yd self PBAoE
    if not (NS.aoe_self_meets and NS.aoe_self_meets(2, (NS.AOE_RADIUS and NS.AOE_RADIUS.SELF_8) or 8, context, state)) then
        return false
    end
    return true
end

local function demo_shout_matches_fn(context, state)
    if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.DemoralizingShout, 2.0) then return false end
    if (state.demo_remains or 0) > 5 then return false end
    return true
end

local function heroic_strike_matches_fn(context, state)
    if (state.rage or 0) < HEROIC_STRIKE_RAGE_DUMP then return false end
    if state.revenge_ready then return false end
    return true
end

local function cleave_matches_fn(context, state)
    -- Cleave: nearest ally near target (not 40yd density)
    if not (NS.aoe_target_meets and NS.aoe_target_meets(2, (NS.AOE_RADIUS and NS.AOE_RADIUS.TARGET_8) or 8, context.target, context, state)) then
        return false
    end
    if (state.rage or 0) < HEROIC_STRIKE_RAGE_DUMP then return false end
    return true
end

local function execute_matches_fn(context, state)
    if not NS.is_execute_phase then return false end
    if not NS.is_execute_phase(state.target_hp or 100, 20) then return false end
    -- Vanilla Execute requires Battle or Berserker Stance (not Defensive); a Defensive-Stance
    -- prot tank skips cleanly rather than wasting a tick on a cast the game will block.
    if state.stance ~= STANCE.BATTLE and state.stance ~= STANCE.BERSERKER then return false end
    return true
end

local function battle_shout_matches_fn(context, state)
    if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.BattleShout, 3.0) then return false end
    if state.has_battle_shout then return false end
    return true
end

local function shield_wall_matches_fn(context, state)
    if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.ShieldWall, 3.0) then return false end
    if (state.hp or 100) > LOW_HP_LIMIT then return false end
    if state.has_shield_wall then return false end
    return true
end

local function last_stand_matches_fn(context, state)
    if NS.broken_api_throttled and NS.broken_api_throttled(SPELLS.LastStand, 3.0) then return false end
    if (state.hp or 100) > LOW_HP_LIMIT then return false end
    if state.has_last_stand then return false end
    return true
end

local function pummel_matches_fn(context, state)
    if not state.target_is_casting then return false end
    if not (state.target_casting_interruptible or false) then return false end
    if not state.pummel_ready then return false end
    if state.stance ~= STANCE.BERSERKER then return false end
    return true
end

local function shield_bash_matches_fn(context, state)
    if not state.target_is_casting then return false end
    if not (state.target_casting_interruptible or false) then return false end
    if not state.shield_bash_ready then return false end
    if not is_defensive_stance(state.stance) then return false end
    return true
end

local function taunt_matches_fn(context, state)
    if not state.taunt_ready then return false end
    -- Vanilla Taunt is a single-target rescue; works on any mob count (1+).
    -- The previous `enemy_count < 2` gate disabled single-boss taunt-swaps.
    return true
end

local function mocking_blow_matches_fn(context, state)
    if not state.mocking_ready then return false end
    if state.stance ~= STANCE.BATTLE then return false end  -- Vanilla Mocking Blow requires Battle Stance
    -- Mocking Blow is a single-target forced-attack; works on any mob count.
    -- The previous `enemy_count < 2` gate disabled single-target rescue.
    return true
end

local function challenging_shout_matches_fn(context, state)
    if not state.challenging_ready then return false end
    if (state.enemy_count or 0) < 3 then return false end
    return true
end

local function disarm_matches_fn(context, state)
    if not state.disarm_ready then return false end
    if not state.is_pvp then return false end
    return true
end

local function intercept_matches_fn(context, state)
    if not state.intercept_ready then return false end
    if state.stance ~= STANCE.BERSERKER then return false end  -- Vanilla Intercept requires Berserker Stance
    if not state.is_pvp then return false end
    return true
end

local function hamstring_matches_fn(context, state)
    if not state.hamstring_ready then return false end
    if not state.is_pvp then return false end
    return true
end

local function berserker_rage_matches_fn(context, state)
    if not state.berserker_rage_ready then return false end
    return true
end

local function bloodrage_matches_fn(context, state)
    if not state.bloodrage_ready then return false end
    if state.in_combat and (state.rage or 0) >= 10 then return false end
    return true
end

local function rend_matches_fn(context, state)
    if not context.target then return false end
    if not state.rend_ready then return false end
    if not state.in_combat then return false end
    if state.revenge_ready then return false end
    local rend_remains = context.target and NS.debuff_remains and NS.debuff_remains(context.target, REND_DEBUFF) or 0
    if rend_remains > 3 then return false end
    return true
end

local function intimidating_shout_matches_fn(context, state)
    if not state.intimidating_shout_ready then return false end
    if not state.in_combat then return false end
    if (state.enemy_count or 0) < 3 then return false end
    if (state.hp or 100) > 50 then return false end
    return true
end

local strategies = {
    {
        name = "HealthPotion",
        matches = function(context)
            if not context.in_combat then return false end
            if context.settings and context.settings.use_auto_potions == false then return false end
            if not context.has_health_potion then return false end
            if (context.hp or 100) > 35 then return false end
            return true
        end,
        execute = function(context) return potion_helper.try_use_potion(context, potion_helper.HEALTH_POTION_IDS) end,
    },
    {
        name = "DamagePotion",
        matches = function(context)
            if not context.in_combat then return false end
            if context.settings and context.settings.use_auto_potions == false then return false end
            if not context.has_damage_potion then return false end
            if not context.should_burst then return false end
            return true
        end,
        execute = function(context) return potion_helper.try_use_potion(context, potion_helper.DAMAGE_POTION_IDS) end,
    },
    {
        name = "LastStand",
        matches = function(context) return last_stand_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.LastStand, context.me or NS.GetPlayer(), "[PROT] LastStand", { skip_range = true, expected_cooldown = LAST_STAND_CD })
        end,
    },
    {
        name = "ShieldWall",
        matches = function(context) return shield_wall_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.ShieldWall, context.me or NS.GetPlayer(), "[PROT] ShieldWall", { skip_range = true, expected_cooldown = SHIELD_WALL_CD })
        end,
    },
    {
        name = "Pummel",
        matches = function(context) return pummel_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Pummel, context.target, "[PROT] Pummel")
        end,
    },
    {
        name = "ShieldBash",
        matches = function(context) return shield_bash_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.ShieldBash, context.target, "[PROT] ShieldBash")
        end,
    },
    {
        name = "Revenge",
        matches = function(context)
            local s = build_state(context)
            return is_defensive_stance(s.stance) and s.revenge_ready
        end,
        execute = function(context) return NS.try_cast(SPELLS.Revenge, context.target, "[PROT] Revenge", { expected_cooldown = REVENGE_CD }) end,
    },
    {
        name = "ShieldSlam",
        matches = function(context)
            local s = build_state(context)
            return is_defensive_stance(s.stance) and s.shield_slam_ready
        end,
        execute = function(context) return NS.try_cast(SPELLS.ShieldSlam, context.target, "[PROT] ShieldSlam", { expected_cooldown = SHIELD_SLAM_CD }) end,
    },
    {
        name = "Taunt",
        matches = function(context) return taunt_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Taunt, context.target, "[PROT] Taunt")
        end,
    },
    {
        name = "MockingBlow",
        matches = function(context) return mocking_blow_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.MockingBlow, context.target, "[PROT] MockingBlow")
        end,
    },
    {
        name = "ChallengingShout",
        matches = function(context) return challenging_shout_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.ChallengingShout, context.me or NS.GetPlayer(), "[PROT] ChallengingShout", { skip_range = true })
        end,
    },
    {
        name = "ShieldBlock",
        matches = function(context)
            local s = build_state(context)
            if not is_defensive_stance(s.stance) then return false end
            if not s.shield_block_ready then return false end
            -- Use buff ID 2565, not the spell-action object (same fix as TBC prot audit P5)
            local me = context.me or NS.GetPlayer()
            local sb_remains = me and NS.buff_remains and NS.buff_remains(me, SHIELD_BLOCK_BUFF) or 0
            if sb_remains > 2 then return false end
            return true
        end,
        execute = function(context) return NS.try_cast(SPELLS.ShieldBlock, context.me or NS.GetPlayer(), "[PROT] ShieldBlock", { skip_range = true, expected_cooldown = SHIELD_BLOCK_CD }) end,
    },
    {
        name = "SunderArmor",
        matches = function(context) return sunder_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.SunderArmor, context.target, "[PROT] Sunder")
        end,
    },
    {
        name = "Execute",
        matches = function(context) return execute_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Execute, context.target, "[PROT] Execute")
        end,
    },
    {
        name = "ThunderClap",
        matches = function(context) return thunderclap_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.ThunderClap, context.me or NS.GetPlayer(), "[PROT] ThunderClap", { skip_range = true, expected_cooldown = THUNDERCLAP_CD })
        end,
    },
    {
        name = "DemoralizingShout",
        matches = function(context) return demo_shout_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.DemoralizingShout, context.me or NS.GetPlayer(), "[PROT] DemoShout", { skip_range = true, expected_cooldown = DEMO_SHOUT_CD })
        end,
    },
    {
        name = "BattleShout",
        matches = function(context) return battle_shout_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.BattleShout, context.me or NS.GetPlayer(), "[PROT] BattleShout", { skip_range = true })
        end,
    },
    {
        name = "Cleave",
        matches = function(context) return cleave_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Cleave, context.target, "[PROT] Cleave")
        end,
    },
    {
        name = "HeroicStrike",
        matches = function(context) return heroic_strike_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.HeroicStrike, context.target, "[PROT] HeroicStrike")
        end,
    },
    {
        name = "Disarm",
        matches = function(context)
            if not spec_kit.setting_bool(context, "use_disarm", true) then return false end
            if not (NS.is_spell_learned and NS.is_spell_learned(676)) then return false end
            if not context.in_combat then return false end
            return disarm_matches_fn(context, build_state(context))
        end,
        execute = function(context)
            return NS.try_cast(SPELLS.Disarm, context.target, "[PROT] Disarm", { expected_cooldown = DISARM_CD })
        end,
    },
    {
        name = "Hamstring",
        matches = function(context) return hamstring_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Hamstring, context.target, "[PROT] Hamstring")
        end,
    },
    {
        name = "Intercept",
        matches = function(context) return intercept_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Intercept, context.target, "[PROT] Intercept")
        end,
    },
    {
        name = "BerserkerRage",
        matches = function(context) return berserker_rage_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.BerserkerRage, context.me or NS.GetPlayer(), "[PROT] BerserkerRage", { skip_range = true })
        end,
    },
    {
        name = "Bloodrage",
        matches = function(context) return bloodrage_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Bloodrage, context.me or NS.GetPlayer(), "[PROT] Bloodrage", { skip_range = true, skip_gcd = true })
        end,
    },
    {
        name = "Rend",
        matches = function(context) return rend_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.Rend, context.target, "[PROT] Rend")
        end,
    },
    {
        name = "IntimidatingShout",
        matches = function(context) return intimidating_shout_matches_fn(context, build_state(context)) end,
        execute = function(context)
            return NS.try_cast(SPELLS.IntimidatingShout, context.me or NS.GetPlayer(), "[PROT] IntimidatingShout", { skip_range = true })
        end,
    },
}

NS.rotation_registry:register("protection", strategies, { get_state = build_state })
-- Warrior protection_vanilla rotation registered (Classic Vanilla)
return strategies
